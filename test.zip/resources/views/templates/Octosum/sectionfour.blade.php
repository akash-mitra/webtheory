<div
class="flex flex-col items-center  my-6 px-8 lg:px-0 lg:pl-16 mx-auto w-full text-gray-700"
>
  <div
    class="text-xl px-8 pt-10 lg:text-4xl leading-tight tracking-normal font-bold text-center self-center"
    style="color:#0061af;"
  >
    Designed to ease Subscription management
  </div>
  <div
    class="mt-16 mb-12 px-10 lg:px-10  w-full flex flex-col-reverse md:flex-row"
  >
    <div
      class="w-full flex flex-col lg:justify-center lg:w-2/5  mt-12 lg:mt-0"
    >
      <div class="w-full flex flex-col">
        <div id="mediaTitle1" class="lg:text-4xl text-2xl leading-tight tracking-normal font-bold text-center lg:text-left">Dashboard</div>
        <div id="mediaDesc1" class="leading-tight tracking-normal font-normal lg:text-xl text-lg text-center lg:text-left mt-4 lg:mt-4">
          A single window view of how, where and whom the subscriptions are allotted and utilized for business planning and evaluation
        </div>

        <div id="mediaTitle2" class="lg:text-4xl text-2xl leading-tight tracking-normal font-bold text-center lg:text-left hidden">Marketplace</div>
        <div id="mediaDesc2" class="leading-tight tracking-normal font-normal lg:text-xl text-lg text-center lg:text-left mt-4 lg:mt-4 hidden">
          List of vendors categorized based on technology and services for easy onboarding
        </div>

        <div id="mediaTitle3" class="lg:text-4xl text-2xl leading-tight tracking-normal font-bold text-center lg:text-left hidden">Users</div>
        <div id="mediaDesc3" class="leading-tight tracking-normal font-normal lg:text-xl text-lg text-center lg:text-left mt-4 lg:mt-4 hidden">
          Allocate visibility based on user requirements
        </div>

        <div id="mediaTitle4" class="lg:text-4xl text-2xl leading-tight tracking-normal font-bold text-center lg:text-left hidden">Vendors</div>
        <div id="mediaDesc4" class="leading-tight tracking-normal font-normal lg:text-xl text-lg text-center lg:text-left mt-4 lg:mt-4 hidden">
          Onboarded Vendor details for quicker tracking and faster decision making
        </div>

        <div id="mediaTitle5" class="lg:text-4xl text-2xl leading-tight tracking-normal font-bold text-center lg:text-left hidden">Projects</div>
        <div id="mediaDesc5" class="leading-tight tracking-normal font-normal lg:text-xl text-lg text-center lg:text-left mt-4 lg:mt-4 hidden">
          Micro level view of project subscription for better planning
        </div>

        <div id="mediaTitle6" class="lg:text-4xl text-2xl leading-tight tracking-normal font-bold text-center lg:text-left hidden">Business Users</div>
        <div id="mediaDesc6" class="leading-tight tracking-normal font-normal lg:text-xl text-lg text-center lg:text-left mt-4 lg:mt-4 hidden">
          View Your Business users department wise for better visibility of subscription allocation and management
        </div>

        <div id="mediaTitle7" class="lg:text-4xl text-2xl leading-tight tracking-normal font-bold text-center lg:text-left hidden">Deployments</div>
        <div id="mediaDesc7" class="leading-tight tracking-normal font-normal lg:text-xl text-lg text-center lg:text-left mt-4 lg:mt-4 hidden">
          A detailed view of all the subscription starting from procurement to allocation for faster tracking
        </div>

      </div>
      <div class="w-full flex mt-12 lg:mt-4">
        <button id="mediaButton1" onclick="selectedSlide(1)" class="dot__slider selected__dot__slider"></button>
        <button id="mediaButton2" onclick="selectedSlide(2)" class="dot__slider"></button>
        <button id="mediaButton3" onclick="selectedSlide(3)" class="dot__slider"></button>
        <button id="mediaButton4" onclick="selectedSlide(4)" class="dot__slider"></button>
        <button id="mediaButton5" onclick="selectedSlide(5)" class="dot__slider"></button>
        <button id="mediaButton6" onclick="selectedSlide(6)" class="dot__slider"></button>
        <button id="mediaButton7" onclick="selectedSlide(7)" class="dot__slider"></button>

      </div>
    </div>
    <div class="w-full lg:w-3/5 pr-2">
      <img id="mediaImage1" src="/storage/media/Vqbn6xA2RbaQ8BDC3JQhvOd2TkzZgRJ3nlP4N9Gx.png" class="border shadow-lg rounded-lg"/>
      <img id="mediaImage2" src="/storage/media/Wi21NyxJGqFAqFTBWk3c9G9omnPhN13hY4FhOo0f.png" class="border shadow-lg rounded-lg hidden"/>
      <img id="mediaImage3" src="/storage/media/5jyWeHzftD04uTl95IkM8uhgJbktj4SWnDCwiucy.png" class="border shadow-lg rounded-lg hidden"/>
      <img id="mediaImage4" src="/storage/media/TzsywP9CjFQN1rFZo3lXzpMCGYY2qYBctAWOEEly.png" class="border shadow-lg rounded-lg hidden"/>
      <img id="mediaImage5" src="/storage/media/MLaRASNqvgyq6prnF3ulVpclNCxl0DxyYPejNgyk.png" class="border shadow-lg rounded-lg hidden"/>
      <img id="mediaImage6" src="/storage/media/iDB4kZHWAYQWamvftvTnt6ffONHzk7UCnxpiU1LY.png" class="border shadow-lg rounded-lg hidden"/>
      <img id="mediaImage7" src="/storage/media/YeyIwM44P7Yu4jYXIdrtKOCHgmK7XUqsvy3RBrrX.png" class="border shadow-lg rounded-lg hidden"/>
    </div>
  </div>
</div>