@extends('active.master')

@section('metadesc'){{ 'Privacy -' . $data->ref->site->title  }}@endsection

@section('metakeys'){{ 'privacy, policy' }}@endsection

@push('headers')
<link rel="canonical" href="{{ url('privacy') }}">
@endpush


@section('contents')

<div style="background: #e7fbff;">
  <div class="container px-6 mx-auto flex flex-col py-6">
    <div class="flex flex-col p-10">
      <div class="text-left">
        <h1
          class=" text-xl  lg:text-4xl leading-tight tracking-normal font-bold self-center"
          style="color:#0061af;"
        >
          Octosum Policies, Cookies, Terms & Legal Stuff
        </h1>
      </div>
      <div
        class="mt-10 text-lg lg:text-xl leading-tight font-semibold tracking-normal text-gray-800"
      >
        <ul class="list-inside list-disc">
          <li>
            <a
              href="{{ url('privacy') }}"
              class="border-b-2 border-gray-800 hover:border-vendor-500"
            >
              Privacy
            </a>
          </li>
          <li class="mt-4">
            <a
              href="{{ url('cookies') }}"
              class="border-b-2 border-gray-800 hover:border-vendor-500"
            >
              Cookies
            </a>
          </li>
        </ul>
      </div>
      <div class="mt-10">
        <div class="flex flex-col">
          <div>
          <h1
              class=" text-xl  lg:text-4xl leading-tight tracking-normal font-bold self-center"
              style="color:#0061af;"
          >
              Privacy
          </h1>
          </div>
          <div
          class="flex flex-col mt-6 text-left text-sm lg:text-xl leading-tight tracking-normal text-gray-700"
          >
          <p>Octosum respects your privacy.</p>
          <p class="mt-4">
              We want to make use of your identifying information that you provide to
              us for purposes of serving you better. Identifying information is
              information that enables us to identify you, such as your email address,
              name, title and address. Octosum uses the individual identifying
              information in order to personalize your experience on our website and
              also to be able to selectively send you communications that may be of
              interest to you, either electronically or otherwise.
          </p>
          <p class="mt-4">
              Octosum policy regarding use of your individual identifying information
              supplied to us or collected via your experience at our website,
              <a href="https://octosum.com" style="color:#0061af;" class="underline"
              >www.octosum.com</a
              >
              covers these areas:
          </p>
          <p class="mt-4 underline font-semibold">
              1. Disclosure
          </p>
          <p class="mt-4">
              This Online Privacy Statement is made available to you in order to make
              you aware of how Octosum collects and uses individual identifying
              information of visitors to
              <a href="https://octosum.com" style="color:#0061af;" class="underline"
              >www.octosum.com</a
              >. Octosum collects the following information regarding visitors to our
              website: domain name, name, information regarding what pages are
              accessed, information volunteered by you, such as survey information,
              email address, or site registrations, and visitor&#39;s preferred means
              of communication.
          </p>
          <p class="mt-4 underline font-semibold">
              2. Agreement
          </p>
          <p class="mt-4">
              Access to certain of
              <a href="https://octosum.com" style="color:#0061af;" class="underline"
              >www.octosum.com</a
              >
              web pages requires a login and password. The use of those  web pages,
              and the information or programs downloadable from those sites, may be
              governed by a written agreement between your employer and Octosum. Your
              individual identifying information  may be retained by Octosum to verify
              compliance with the agreement, to log software licenses  granted, to
              track software downloaded from those pages, or to track usage of other
              applications  available on
              <a href="https://octosum.com" style="color:#0061af;" class="underline"
              >www.octosum.com</a
              >.
          </p>
          <p class="mt-4 underline font-semibold">
              3. Data security and quality
          </p>
          <p class="mt-4">
              Octosum is committed to taking reasonable steps to protect the
              individual identifying information that you provide to us. The accuracy
              of your individual identifying information is important to Octosum.  We
              are working on ways to make it easier for you to review and correct the
              information that  Octosum maintains about you.
          </p>
          <p class="mt-4 underline font-semibold">
              4. Use of Cookies
          </p>
          <p class="mt-4">
              A cookie is a small data file that certain web sites write to
              visitor&#39;s hard drive when he visits them. A cookie file can contain
              information such as a user ID that the site uses to track the pages
              you&#39;ve visited, but the only personal information a cookie can
              contain is information you supply yourself. A cookie can&#39;t read data
              off visitor&#39;s hard disk or read cookie files created by other sites.
              Some parts of
              <a href="https://octosum.com" style="color:#0061af;" class="underline"
              >www.octosum.com</a
              >
              use cookies to track user traffic patterns. We do this in order to
              determine the usefulness of
              <a href="https://octosum.com" style="color:#0061af;" class="underline"
              >www.octosum.com</a
              >
              information to our users and to see how effective our navigational
              structure is in helping users reach that information. Octosum does not
              correlate this information with data about individual users, nor does
              it share this information or sell it to any third party.
          </p>
          </div>
      </div>
      </div>
    </div>
  </div>
</div>
  
@endsection