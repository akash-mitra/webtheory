@component('mail::message')
# Hello

There is a new enquiry from Chatbot. Below are the details:

@component('mail::table')
| Key           | Info                           |
|:------------- |:-------------------------------|
| Name          | {{ $details['name'] }}         |
| Email         | {{ $details['email'] }}        |
| Phone         | {{ $details['phone'] }}        |
| Subject       | {{ $details['subject'] }}      |
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent