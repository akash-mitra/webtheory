@extends('active.master')

@section('metadesc'){{ 'About Octosum -' . $data->ref->site->title  }}@endsection

@section('metakeys'){{ 'about octosum, octosum, ashnik' }}@endsection

@push('headers')
<link rel="canonical" href="{{ url('about') }}">
@endpush


@section('contents')

  <div class="mx-auto h-full flex flex-col pt-10" style="background: #e7fbff;">
    <div
      class="w-full md:w-1/2 lg:w-3/5 self-center text-gray-800 leading-relaxed tracking-wide flex flex-col lg:flex-row p-6 lg:p-0"
    >
      <div class="mr-12 hidden lg:block ">
        <img class="h-auto" src="/storage/media/qPcLRBIGxRl2gi5Ltzd56AheC2umXXBKF6tIZQQf.png" alt="about us graphic" />
      </div>
      <div class="self-center leading-relaxed tracking-wide -mt-8 ">
        <p class="text-3xl md:text-4xl tracking-tighter font-thin">
          Octosum – The intelligent subscription management system
        </p>
        <p class="text-xl md:text-2xl  font-thin text-gray-600">
          A product by Ashnik
        </p>
      </div>
    </div>
    <div class="lg:opacity-75 -mt-4 lg:-mt-24">
      <svg
        version="1.1"
        id="Layer_1"
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        x="0px"
        y="0px"
        viewBox="0 0 2127 303"
        style="enable-background:new 0 0 2127 303;"
        xml:space="preserve"
      >
        <linearGradient
          id="SVGID_1_"
          gradientUnits="userSpaceOnUse"
          x1="-1.7335"
          y1="112.9659"
          x2="2156.3125"
          y2="112.9659"
        >
          <stop offset="0" style="stop-color:#B0ECF6" />
          <stop offset="1" style="stop-color:#87F1F6" />
        </linearGradient>
        <path
          style="fill:url(#SVGID_1_);"
          d="M-1.45,79.97c51.1-28.04,130.68-62.3,226.36-60.3c100.24,2.1,124.38,41.08,241.97,49.99
	C590.29,79,606.41,38.8,735.85,42.8c148.92,4.59,156.09,58.4,280.22,58.06c153.2-0.42,174.73-82.63,325.38-83.32
	c139.07-0.63,153.86,69.23,291.48,65.98c136.35-3.23,171.69-73.08,304.62-73.86c96.3-0.56,172.69,35.51,218.77,62.84v143.77H-1.73
	L-1.45,79.97z"
        />
        <linearGradient
          id="SVGID_2_"
          gradientUnits="userSpaceOnUse"
          x1="-23.6875"
          y1="151.4842"
          x2="2136.3125"
          y2="151.4842"
        >
          <stop offset="0" style="stop-color:#CDF2FF" />
          <stop offset="1" style="stop-color:#88FCFF" />
        </linearGradient>
        <path
          style="fill:url(#SVGID_2_);"
          d="M-23.69,61.65c66.24,35.71,157.62,72.85,258.59,62.86c100.49-9.95,116.83-57.61,214.07-64.73
	c135.53-9.93,171.05,77.59,312.91,75.62c128.18-1.78,137.58-73.84,273.15-80.42c142.84-6.94,170.4,71.17,321.53,67.77
	c137.18-3.09,146.19-68.17,277.46-66.22c131.64,1.96,169.39,68.12,302.89,67.78c86.81-0.22,156.21-28.41,199.41-50.45v174.56h-2160
	V61.65z"
        />
        <path
          style="fill:#E7FBFF;"
          d="M-21.45,177.97c51.1-28.04,130.68-62.3,226.36-60.3c100.24,2.1,124.38,41.08,241.97,49.99
	C570.29,177,586.41,136.8,715.85,140.8c148.92,4.59,156.09,58.4,280.22,58.06c153.2-0.42,174.73-82.63,325.38-83.32
	c139.07-0.63,153.86,69.23,291.48,65.98c136.35-3.23,171.69-73.08,304.62-73.86c96.3-0.56,172.69,35.51,218.77,62.84v143.77H-21.73
	L-21.45,177.97z"
        />
      </svg>
    </div>
    <div
      class="w-full md:w-1/2 lg:w-3/5 self-center text-gray-900  text-base  font-medium leading-loose tracking-normal p-12 lg:p-0 "
    >
      <p class="mb-4">
        Octosum, a SAAS platform, enables enterprises to get more value out of
        their open source subscriptions. The platform is developed based on
        extensive inputs from large enterprises about the challenges they have
        been facing on managing their enterprise open subscriptions across their
        different teams – Procurement, Compliance, IT and Business. Octosum is
        designed to go beyond just subscription management by offering vendor
        engagement, order management, and IT vendor marketplace.
      </p>
      <p class="mb-4">
        The product is conceptualized and developed by Ashnik, who are well
        known for their proficiency in open source enables technologies and
        solutions. Having worked with several enterprises across Southeast Asia
        and India, they have digitally transformed their customer IT landscapes
        via design, architecting and solutions skills. Their core focus is
        modernization using open source technologies for database management,
        containerization, data integration, IT infrastructure monitoring, and
        application delivery platforms.
      </p>
      <p class="mb-4">
        Recognized as a leading enterprise open source solutions and consulting
        company in Southeast Asia and India, Ashnik has empowered several large
        enterprises, delivering solutions and services – the open source way.
        Adding Octosum to their latest offerings, is one more way they intend to
        add value to their customer base. <br />Read more about
        <a href="https://octosum.com" class="hover:underline text-customer-500"
          >how Octosum can help you.</a
        >
      </p>
    </div>
  </div>

@endsection