@extends('active.master')

@section('metadesc'){{ 'Security -' . $data->ref->site->title  }}@endsection

@section('metakeys'){{ 'security' }}@endsection

@push('headers')
<link rel="canonical" href="{{ url('security') }}">
@endpush


@section('contents')

<div class="text-gray-700" style="background: #e7fbff;">
  <div class="container px-6 mx-auto flex flex-col py-6 justify-center">
    <div class="flex flex-col px-10">
      <div class="self-start">
        <h1
          class=" text-xl  lg:text-4xl leading-tight tracking-normal font-bold self-center"
          style="color:#0061af;"
        >
          Security
        </h1>
      </div>
      <div class="flex flex-col self-start">
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Your Security and Privacy are Important to us
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          Octosum Open source subscription management platform prioritizes
          security and privacy of its users. Octosum provides enterprise-class
          security and ensures that your organization’s data is completely
          private and protected.
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Secure Your Access
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          OAuth-based authentication. External OAuth providers support (e.g.
          Google) and role-based access for internal controls.
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Data Encryption at Rest and in Transit
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          All sensitive data is encrypted at the application level using
          AES-256 GCM encryption and served over secure connections to
          customers. We encrypt all data that goes between you and Octosum
          using industry-standard TLS (Transport Layer Security), protecting
          your account data. Your data is also encrypted at rest when it is
          stored on our servers.
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Hosting and Physical Security
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          Octosum servers are hosted on
          <a
            href="https://aws.amazon.com/"
            style="color:#0061af;"
            class="underline"
            >Amazon Web Services (AWS)</a
          >
          . As such, Octosum inherits the control environment which Amazon
          maintains and demonstrates via SSAE16 SOC 1, 2 and 3, ISO 27001 and
          FedRAMP/FISMA reports and certifications. Web servers and databases
          run on servers in secure data centers. Physical access is restricted
          to authorized personnel. Premises are monitored and access is
          logged. You can read further about AWS security and certifications
          here:
          <a
            href="https://aws.amazon.com/security"
            style="color:#0061af;"
            class="underline"
            >https://aws.amazon.com/security</a
          >
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Network Security
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          Octosum services are accessible only over HTTPS. Traffic over HTTPS
          is encrypted and is protected from interception by unauthorized
          third parties. Octosum uses only strong encryption algorithms with a
          key length of at least 128 bits. Octosum servers deny access to
          other ports, except that SSH access (protected by TLS and private
          key authentication) is enabled for administration. Administrative
          access is granted only to select employees of Octosum, based on role
          and business need. Access to databases used in the Octosum is
          limited to interhost communication only. <br />
          All network access, both within the data center and between the data
          center and outside services, is restricted by firewall and routing
          rules. Network access is logged and logs are retained for a minimum
          of 30 days.
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Disaster recovery and readiness
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          Octosum performs real-time data replication between AWS availability
          zones, protected facilities, to ensure your data is available and
          safely stored. This means that should even an unlikely event occur,
          such as an entire hosting facility failure, we can switch over
          quickly to a backup site to keep Octosum and your business running.
          We transmit data securely, across encrypted links.
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Authentication
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          Clients login to Octosum using a password which is known only to
          them and done only over secure (HTTPS) connections. Clients are
          required to have reasonably strong passwords. Passwords are not
          stored unencrypted; instead, as is standard practice, only a secure
          hash of the password is stored in the database. Because the hash is
          relatively expensive to compute, and because a “salting” method is
          used, brute-force guessing attempts are relatively ineffective, and
          password reverse-engineering is difficult even if the hash value
          were to be obtained by a malicious party.<br />
          In addition we offer the option of using two-step authentication.
          This provides a second level of security for your Octosum account.
          It means you’re also asked to enter a unique code generated by a
          separate authenticator app on your smartphone. We recommend you to
          use two-step authentication as it reduces the risk of your Octosum
          account being accessed if your password is compromised.
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          End-user Auditable Logs
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          Complete and auditable end-user logs of key activities.
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Constant updates and innovation
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          We’re constantly enhancing Octosum, delivering new features,
          performance improvements and bug or security fixes. Updates are
          delivered frequently, with the majority of them being delivered
          without interrupting our service and disrupting users.
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Data Privacy
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          Octosum has a privacy policy, which details the steps we take to
          protect clients’ information. You can view the privacy policy here:
          <a
            href="https://octosum.com/privacy"
            style="color:#0061af;"
            class="underline"
            >https://octosum.com/privacy</a
          >
        </div>
        <div
          class="text-lg lg:text-xl leading-tight tracking-normal font-semibold mt-8"
        >
          Reporting Security Issues
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2"
        >
          At Octosum, we consider the security of our systems a top priority.
          But no matter how much effort we put into system security, there can
          still be vulnerabilities present. We have implemented a responsible
          disclosure policy to ensure that problems are addressed quickly and
          safely. If you discover a vulnerability, we would like to know about
          it so we can take steps to address it as quickly as possible. Please
          contact us at info@Octosum.com
        </div>
      </div>
    </div>
  </div>
</div>

@endsection