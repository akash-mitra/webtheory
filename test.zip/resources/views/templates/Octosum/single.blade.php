@extends('active.wtmaster')

@section('metadesc'){{ $data->page->metadesc  }}@endsection

@section('metakeys'){{ $data->page->metakey }}@endsection

@push('headers')
<link rel="canonical" href="{{ $data->page->permalink }}">

<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="{{ $data->page->title  }}" />
<meta property="og:description" content="{{ $data->page->metadesc  }}" />
<meta property="og:url" content="{{ $data->page->permalink }}" />
<meta property="og:site_name" content="Octosum" />
<meta property="og:image" content="{{ url($data->page->media->url) }}" />

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="{{ $data->page->title }}" />
<meta name="twitter:description" content="{{ $data->page->metadesc  }}" />
<!-- <meta name="twitter:site" content="@sauravmitra84" /> -->
<meta name="twitter:image" content="{{ url($data->page->media->url) }}" />
<!-- <meta name="twitter:creator" content="@sauravmitra84"/> -->
<meta name="twitter:domain" content="octosum.com">

@endpush


@section('contents')

    

    <div class="w-full max-w-6xl mx-auto px-6 md:px-8">


        <main class="w-full max-w-3xl @if($data->ref->template->centerContent === 'yes') mx-auto @endif py-10 px-6 text-gray-800">
            <article class="wt-typography">
                <header>
                    <a href="{{ $data->page->category->url }}" class="text-blue-400">
                        {{ $data->page->category->name }}
                    </a>
                    <h1 class="text-gray-800 text-4xl font-serif">{{ $data->page->title }}</h1>
                    <div class="w-full flex items-center mt-6 mb-8 text-sm">
                        <a href="{{ $data->page->author->url }}">
                        <img src="{{ $data->page->author->avatar }}" class="h-12 w-12 border-2 rounded-full" />
                        </a>
                        <div class="ml-4">
                            <div class="w-full">{{ $data->page->author->name }}</div>
                            <div class="w-full">Updated on {{ $data->page->updated_at->format('M d, Y') }}</div>
                        </div>
                    </div>

                    <p class="wt-summary bg-{{$data->ref->template->primaryColor}}-100">{{ $data->page->summary }}</p>

                    <div class="flex flex-inline mt-4">
                      @sharepost
                    </div>
                </header>
                <div class="mt-4 text-base wt-body">
                    {!! $data->page->content->body_html !!}
                </div>
            </article>

            @comments

        </main>

    </div>

@endsection