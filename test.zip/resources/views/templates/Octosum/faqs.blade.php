@extends('active.master')

@section('metadesc'){{ 'Frequently asked Questions -' . $data->ref->site->title  }}@endsection

@section('metakeys'){{ 'faq, faqs, frequently asked questions' }}@endsection

@push('headers')
<link rel="canonical" href="{{ url('faqs') }}">
@endpush


@section('contents')
  
<div style="background: #e7fbff;">
  <div class="container px-6 mx-auto flex flex-col py-6 justify-center">
    <div class="flex flex-col px-10 ">
      <div
        class="flex flex-col-reversed lg:flex-row justify-between w-full lg:w-4/5 self-center"
      >
        <div class="self-center">
          <h1
            class=" text-xl  lg:text-4xl leading-tight tracking-normal font-bold self-center"
            style="color:#0061af;"
          >
            Frequently Asked Questions
          </h1>
        </div>
        <div>
          <svg
            version="1.1"
            id="Layer_1"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            x="0px"
            y="0px"
            viewBox="0 0 676 759"
            enable-background="new 0 0 676 759"
            xml:space="preserve"
            class="fill-current h-full w-full"
          >
            <g>
              <g>
                <rect
                  x="554.9"
                  y="475.1"
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#77CEF4"
                  stroke="#FFFFFF"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-miterlimit="10"
                  width="88.3"
                  height="63.4"
                />

                <line
                  fill="#77CEF4"
                  stroke="#FFFFFF"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-miterlimit="10"
                  x1="554.9"
                  y1="475.1"
                  x2="599.3"
                  y2="517.7"
                />

                <line
                  fill="#77CEF4"
                  stroke="#FFFFFF"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-miterlimit="10"
                  x1="643.2"
                  y1="475.1"
                  x2="599.3"
                  y2="517.7"
                />

                <line
                  fill="#77CEF4"
                  stroke="#FFFFFF"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-miterlimit="10"
                  x1="586.8"
                  y1="505.7"
                  x2="554.9"
                  y2="538.5"
                />

                <line
                  fill="#77CEF4"
                  stroke="#FFFFFF"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-miterlimit="10"
                  x1="612"
                  y1="505.4"
                  x2="643.2"
                  y2="538.5"
                />
              </g>
            </g>
            <g>
              <g>
                <path
                  fill="#77CEF4"
                  d="M619.4,367.4c-15.2,0-27.5-12.3-27.5-27.5c0-15.2,12.3-27.5,27.5-27.5c15.2,0,27.5,12.3,27.5,27.5
    C646.9,355,634.5,367.4,619.4,367.4z M619.4,325.6c-7.9,0-14.3,6.4-14.3,14.3c0,7.9,6.4,14.3,14.3,14.3c7.9,0,14.3-6.4,14.3-14.3
    C633.7,332,627.2,325.6,619.4,325.6z"
                />
              </g>
              <g>
                <g>
                  <rect
                    x="612.8"
                    y="304.1"
                    fill="#77CEF4"
                    width="13.2"
                    height="15.4"
                  />
                </g>
                <g>
                  <rect
                    x="612.8"
                    y="360.2"
                    fill="#77CEF4"
                    width="13.2"
                    height="15.4"
                  />
                </g>
                <g>
                  <rect
                    x="583.6"
                    y="333.3"
                    fill="#77CEF4"
                    width="15.4"
                    height="13.2"
                  />
                </g>
                <g>
                  <rect
                    x="639.7"
                    y="333.3"
                    fill="#77CEF4"
                    width="15.4"
                    height="13.2"
                  />
                </g>
                <g>
                  <rect
                    x="592.9"
                    y="312.3"
                    transform="matrix(0.707 -0.7072 0.7072 0.707 -50.6588 517.7825)"
                    fill="#77CEF4"
                    width="13.2"
                    height="15.4"
                  />
                </g>
                <g>
                  <rect
                    x="632.6"
                    y="352"
                    transform="matrix(0.707 -0.7072 0.7072 0.707 -67.1092 557.3967)"
                    fill="#77CEF4"
                    width="13.2"
                    height="15.4"
                  />
                </g>
                <g>
                  <rect
                    x="591.8"
                    y="353.1"
                    transform="matrix(0.707 -0.7072 0.7072 0.707 -78.7274 529.3593)"
                    fill="#77CEF4"
                    width="15.4"
                    height="13.2"
                  />
                </g>
                <g>
                  <rect
                    x="631.5"
                    y="313.4"
                    transform="matrix(0.7073 -0.707 0.707 0.7073 -39.1246 545.5679)"
                    fill="#77CEF4"
                    width="15.4"
                    height="13.2"
                  />
                </g>
              </g>
            </g>
            <g>
              <g>
                <path
                  fill="#079DD9"
                  d="M657.2,190.5c0,43.8-35.5,79.2-79.2,79.2c-43.8,0-79.2-35.5-79.2-79.2c0-43.8,35.5-79.2,79.2-79.2
    C621.7,111.3,657.2,146.8,657.2,190.5z"
                />
                <g>
                  <polyline
                    fill="#079DD9"
                    points="560.7,261.6 536.6,284.7 534.3,257.5 			"
                  />
                </g>
              </g>
              <g>
                <g>
                  <g>
                    <path
                      fill="#00567A"
                      d="M548.9,194.3c4.8,0,4.8-7.5,0-7.5C544,186.8,544,194.3,548.9,194.3L548.9,194.3z"
                    />
                  </g>
                </g>
                <g>
                  <g>
                    <path
                      fill="#00567A"
                      d="M577.7,194.3c4.8,0,4.8-7.5,0-7.5C572.8,186.8,572.8,194.3,577.7,194.3L577.7,194.3z"
                    />
                  </g>
                </g>
                <g>
                  <g>
                    <path
                      fill="#00567A"
                      d="M606.5,194.3c4.8,0,4.8-7.5,0-7.5C601.6,186.8,601.6,194.3,606.5,194.3L606.5,194.3z"
                    />
                  </g>
                </g>
              </g>
            </g>
            <g>
              <path
                fill="none"
                stroke="#079DD9"
                stroke-width="4"
                stroke-miterlimit="10"
                d="M188.3,347.3c0-62.7,48.8-96.9,109-96.9
  c60.2,0,109,34.2,109,96.9"
              />
              <g>
                <g>
                  <path
                    fill="#079DD9"
                    d="M188.6,414.6c0,13.1,1.1,23.7-12.4,23.7l0,0c-13.5,0-24.5-10.6-24.5-23.7v-43.4c0-13.1,11-23.7,24.5-23.7
      l0,0c13.5,0,12.4,10.6,12.4,23.7V414.6z"
                  />
                  <path
                    fill="#013F5B"
                    d="M200.7,435c0,6-4.9,10.8-10.8,10.8l0,0c-6,0-10.8-4.8-10.8-10.8v-84.3c0-6,4.9-10.8,10.8-10.8l0,0
      c6,0,10.8,4.9,10.8,10.8V435z"
                  />
                </g>
                <g>
                  <path
                    fill="#079DD9"
                    d="M406,414.6c0,13.1-1.1,23.7,12.4,23.7l0,0c13.5,0,24.5-10.6,24.5-23.7v-43.4c0-13.1-11-23.7-24.5-23.7
      l0,0c-13.5,0-12.4,10.6-12.4,23.7V414.6z"
                  />
                  <path
                    fill="#013F5B"
                    d="M393.9,435c0,6,4.8,10.8,10.8,10.8l0,0c6,0,10.8-4.8,10.8-10.8v-84.3c0-6-4.9-10.8-10.8-10.8l0,0
      c-6,0-10.8,4.9-10.8,10.8V435z"
                  />
                </g>
              </g>
            </g>
            <g>
              <g>
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#3ABBD5"
                  d="M276.7,486.6c5.8,0.4,11.6,1.9,14.5,5.2c6.3,7.1,7.5,18.1,5,26.4
    c-3.7,12.3-9.7,41.2-10.4,55.4c-1.1,24.3,0.2,35-0.7,59.3c-0.8,19.1-0.1,38.7-5.5,57c-5.6,19.2-19.4,37.5-39.3,41.3
    c-1.9,0.4-4,0.1-5.6-1.1c-4.5-3.3-1.6-9.7,1.2-14.1c6.8-10.8,11.7-22.9,14.4-35.4c4.8-21.9,2.7-44.6,2.1-67
    c-1.1-39.3-4.6-60.3-1.3-99.4c0.4-5,7.7-26.2,12.7-27C267.2,486.6,272,486.3,276.7,486.6z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M267,714.5c-0.1-0.1-0.1-0.2-0.2-0.2c-1.6-1.6-6.1,0.2-9.9,4.1
    c-3.1,3.1-4.9,6.6-4.6,8.6C257.8,723.9,262.8,719.5,267,714.5z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M279,692c-0.1-0.1-0.2-0.2-0.4-0.2c-2.1-0.9-5.5,2.5-7.6,7.5
    c-1.9,4.6-2.1,9-0.5,10.4C274.1,704.3,277,698.2,279,692z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#3ABBD5"
                  d="M218.6,475.1c0,0-13.9,93.7-82.8,72.6
    c-14.2-4.4-36.8-14.1-51.6-14.6c-11.3-0.4-23.2-1-33.8,3.9c-17.3,7.9-27.4,27.9-22.9,46.6c1.6,6.8,6.2,12,13,14
    c4.3,1.3,8.7-1.8,8.8-6.3c0.4-13.5,6.9-38.6,52.4-24.6c32.4,10,92.5,64.2,137.3-26.2l26.7-63.1L218.6,475.1z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#13A9B4"
                  d="M92.1,564.2c11.1,0.6,27.2,3.6,50.5,11.3
    c16.1,5.3,33.6,4,48.7-3.8c16.4-8.4,32.9-21.9,28-40.9l16.2,2.5c0,0-4.9,21.5-19.4,40.5c-40.8,40.7-87.4,1.3-114.6-7.1
    C98.2,565.6,95.1,564.8,92.1,564.2z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#3ABBD5"
                  d="M233.5,465.9c0,0-25.8,114.3-61.3,124
    c-18.7,5.1-35.9,31.4-45.3,47.3c-5.8,9.7-11.1,20.4-15,31.3c-2,5.6-3.8,11.2-5.2,17c-0.9,3.7-4.5,13.1-1.9,16.6
    c0.9,1.2,2.7,1.5,4.1,1c6.5-2.1,10.3-10.6,14.2-15.6c5.9-7.7,11.4-15.5,17.3-23.2c10.8-14.1,29.8-34.4,47.6-39.7
    c55.7-16.6,84.2-158.6,84.2-158.6H233.5z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#13A9B4"
                  d="M237.5,570.5c2-5.7,3.7-12,5.1-19l5.9-30.1
    c0,0-24.3,82.6-60.4,98.7c-21.6,9.6-27.5,18-28.8,23.1c8.9-8.4,19-15.8,28.8-18.7C208.1,618.5,224.6,596.4,237.5,570.5z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M130.4,677.8c-0.1-0.6-0.4-1.1-0.8-1.4c-1.8-1.4-6,1-9.3,5.4
    c-3.3,4.4-4.5,9-2.7,10.4c0.5,0.4,1.3,0.5,2.1,0.3c1.2-1.8,2.3-3.6,3.4-5.1C125.6,684.2,128,681,130.4,677.8z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M146.1,657.2c-0.1-0.4-0.4-0.7-0.6-0.9c-1.8-1.4-6,1-9.3,5.4
    c-3.3,4.4-4.5,9-2.7,10.4c0.2,0.2,0.5,0.3,0.8,0.3c2-2.8,4.1-5.5,6.2-8.2C142.2,662,144.1,659.6,146.1,657.2z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#3ABBD5"
                  d="M278.4,469.2c-3.4-1.9-7.8-0.8-9.9,2.6
    C254.8,493.4,213,586.5,215,615.4c-4.3,66.7-28.3,92.3-46.1,111.1c-4.5,4.8,0.7,12.7,7.2,11.7c21-3.2,66.6-32.5,72.5-119
    c1.3-18.2,2.6-50.2,11.2-66.3c29.5-54.9,27.7-55.9,34.5-65.5c2.6-3.6,1.4-8.7-2.5-10.9L278.4,469.2z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#13A9B4"
                  d="M250.2,573.1c-3,10.2-6.2,48-7.7,58.6c-3,20.3-11.3,57.8-27,81.3
    c15.8-18.3,29.9-48,33.1-93.7c1.3-18.2,2.6-50.2,11.2-66.3l1.5-2.8C259.7,543.4,254.2,559.3,250.2,573.1L250.2,573.1z
      M190.5,733.1L190.5,733.1L190.5,733.1L190.5,733.1z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M198.7,728.2c0-0.4-0.1-0.7-0.2-1c-1.1-2-5.9-1.4-10.6,1.4
    c-4.6,2.7-7.5,6.4-6.6,8.4C186.4,735.4,192.4,732.5,198.7,728.2z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M218,709.8c-0.1-0.2-0.2-0.3-0.4-0.4c-1.8-1.5-6,0.8-9.5,5
    c-3,3.6-4.4,7.4-3.7,9.4C209,720,213.6,715.3,218,709.8z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#3ABBD5"
                  d="M319.4,486.6c-5.8,0.4-11.6,1.9-14.5,5.2
    c-6.3,7.1-7.5,18.1-5,26.4c3.7,12.3,9.7,41.2,10.4,55.4c1.1,24.3-0.2,35,0.7,59.3c0.8,19.1,0.1,38.7,5.5,57
    c5.6,19.2,19.4,37.5,39.3,41.3c1.9,0.4,4,0.1,5.6-1.1c4.5-3.3,1.6-9.7-1.2-14.1c-6.8-10.8-11.7-22.9-14.4-35.4
    c-4.8-21.9-2.7-44.6-2.1-67c1.1-39.3,4.6-60.3,1.3-99.4c-0.4-5-7.7-26.2-12.7-27C329,486.6,324.2,486.3,319.4,486.6z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M329.2,714.5c0.1-0.1,0.1-0.2,0.2-0.2c1.6-1.6,6.1,0.2,9.9,4.1
    c3.1,3.1,4.9,6.6,4.6,8.6C338.3,723.9,333.3,719.5,329.2,714.5z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M317.1,692c0.1-0.1,0.2-0.2,0.4-0.2c2.1-0.9,5.5,2.5,7.6,7.5
    c1.9,4.6,2.1,9,0.5,10.4C322,704.3,319.1,698.2,317.1,692z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#3ABBD5"
                  d="M375.1,482.3c0,0,71.9,61.7,110.1,0.6
    c7.9-12.6,18.5-34.7,29.4-44.8c8.3-7.7,16.9-15.9,28-19.2c18.3-5.4,39,3.2,47.9,20.2c3.2,6.2,3.2,13.1-0.6,19.1
    c-2.4,3.8-7.8,4.3-10.8,1c-9.2-9.9-30.5-24.6-55.7,15.7c-17.9,28.8-27.8,109.1-120.9,70.2L341,514.8L375.1,482.3z"
                />
                <g>
                  <defs>
                    <path
                      id="SVGID_1_"
                      d="M375.1,482.3c0,0,71.9,61.7,110.1,0.6c7.9-12.6,18.5-34.7,29.4-44.8c8.3-7.7,16.9-15.9,28-19.2
        c18.3-5.4,39,3.2,47.9,20.2c3.2,6.2,3.2,13.1-0.6,19.1c-2.4,3.8-7.8,4.3-10.8,1c-9.2-9.9-30.5-24.6-55.7,15.7
        c-17.9,28.8-27.8,109.1-120.9,70.2L341,514.8L375.1,482.3z"
                    />
                  </defs>
                  <clipPath id="SVGID_2_">
                    <use xlink:href="#SVGID_1_" overflow="visible" />
                  </clipPath>
                  <path
                    clip-path="url(#SVGID_2_)"
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    fill="#13A9B4"
                    d="M528.9,466.7
      c-8,7.7-18.2,20.5-30.7,41.6c-8.7,14.5-21.9,34.2-38.3,38.3c-17.9,4.4-78.9-7.8-87.7-25.3l-1.7,11.1c0,0,45.1,22.8,68.5,27.7
      c57.5,4.1,69.4-61.2,84.5-85.3C525.3,471.8,527.1,469.2,528.9,466.7z"
                  />
                </g>
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M564.5,449.2c-1.2-1.6-1.7-3.1-1.1-4.1c1.2-1.9,5.9-1.2,10.6,1.6
    c4.7,2.8,7.5,6.7,6.3,8.7c-0.6,1-2.1,1.3-4,1C573.2,453.5,569.2,450.7,564.5,449.2z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M541,454.3c-1-0.1-1.8-0.5-2.1-1.2c-1.1-2,1.9-5.7,6.7-8.4
    c4.8-2.6,9.6-3.1,10.7-1.1c0.6,1.2-0.1,2.9-1.8,4.7C550.3,448.9,545.8,450.7,541,454.3z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#3ABBD5"
                  d="M362.6,465.9c0,0,25.8,114.3,61.3,124
    c18.7,5.1,35.9,31.4,45.3,47.3c5.8,9.7,11.1,20.4,15,31.3c2,5.6,3.8,11.2,5.2,17c0.9,3.7,4.5,13.1,1.9,16.6
    c-0.9,1.2-2.7,1.5-4.1,1c-6.5-2.1-10.3-10.6-14.2-15.6c-5.9-7.7-11.4-15.5-17.3-23.2c-10.8-14.1-29.8-34.4-47.6-39.7
    c-55.7-16.6-84.2-158.6-84.2-158.6H362.6z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#13A9B4"
                  d="M358.6,570.5c-2-5.7-3.7-12-5.2-19l-5.9-30.1
    c0,0,24.3,82.6,60.4,98.7c21.6,9.6,27.5,18,28.8,23.1c-8.9-8.4-19-15.8-28.8-18.7C388,618.5,371.5,596.4,358.6,570.5z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M465.8,677.8c0.1-0.6,0.4-1.1,0.8-1.4c1.8-1.4,6,1,9.3,5.4
    c3.3,4.4,4.5,9,2.7,10.4c-0.5,0.4-1.3,0.5-2.1,0.3c-1.2-1.8-2.3-3.6-3.4-5.1C470.5,684.2,468.1,681,465.8,677.8z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M450,657.2c0.1-0.4,0.4-0.7,0.6-0.9c1.8-1.4,6,1,9.3,5.4
    c3.3,4.4,4.5,9,2.7,10.4c-0.2,0.2-0.5,0.3-0.8,0.3c-2-2.8-4.1-5.5-6.2-8.2C454,662,452.1,659.6,450,657.2z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#3ABBD5"
                  d="M317.8,469.2c3.5-1.9,7.8-0.8,9.9,2.6
    c13.7,21.7,55.5,114.7,53.5,143.6c4.3,66.7,28.3,92.3,46.1,111.1c4.5,4.8-0.7,12.7-7.2,11.7c-21-3.2-66.6-32.5-72.5-119
    c-1.2-18.2-2.6-50.2-11.2-66.3c-29.5-54.9-27.7-55.9-34.5-65.5c-2.6-3.6-1.4-8.7,2.5-10.9L317.8,469.2z"
                />
                <g>
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    fill="#13A9B4"
                    d="M345.9,573.1c3,10.2,6.2,48,7.7,58.6c3,20.3,11.3,57.8,27,81.3
      c-15.8-18.3-29.9-48-33.1-93.7c-1.2-18.2-2.6-50.2-11.2-66.3l-1.5-2.8C336.4,543.4,341.9,559.3,345.9,573.1L345.9,573.1z
        M405.6,733.1L405.6,733.1L405.6,733.1L405.6,733.1z"
                  />
                </g>
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M397.4,728.2c0-0.4,0.1-0.7,0.2-1c1.1-2,5.9-1.4,10.6,1.4
    c4.6,2.7,7.5,6.4,6.6,8.4C409.7,735.4,403.7,732.5,397.4,728.2z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M378.1,709.8c0.1-0.2,0.2-0.3,0.4-0.4c1.8-1.5,6,0.8,9.5,5
    c3,3.6,4.4,7.4,3.7,9.4C387.1,720,382.5,715.3,378.1,709.8z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M53.8,574.2c-0.1-2-0.8-3.5-1.9-3.8c-2.2-0.7-5.3,3-7,8.2
    c-1.7,5.2-1.3,10,0.9,10.7c1.1,0.4,2.4-0.4,3.7-1.9C50,583.2,51.2,578.4,53.8,574.2z"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#B6DFE6"
                  d="M74.8,562.6c0.7-0.8,1-1.6,0.8-2.3c-0.5-2.2-5.2-3.1-10.6-1.9
    c-5.3,1.2-9.3,3.9-8.8,6.2c0.3,1.3,2,2.1,4.4,2.4C64.3,564.7,68.9,563.1,74.8,562.6z"
                />
              </g>
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                fill="#3ABBD5"
                d="M382.6,442.8c14.3-30.6,19.1-85.5,0.6-116.5
  c-17.7-29.5-60.2-40-78-42.2c1.4-2,1.4-3.2,2.8-5.2c3.9-5.5,6.7-5.7,2.7-5.7c-12.1,0-6.1,13.4-9.8-1.1c-7.1-27.4-4.7,7.5-6.2,5.3
  c-5.5-8-29.3,0.1-26.4,0.2c13.1,0.7,16.4-1.2,21.8,6.4c-15.7,1.7-61.5,11.5-79.2,43.7c-17.1,31.2-15,84.8-0.1,115.1
  c9.5,24.7,7.2,28.3,4,52.7c0,24.6,34.7,16.5,81.9,16.5c47.3,0,90.4,15.4,84.1-21.6C380.9,493,372.3,469.4,382.6,442.8z"
              />
              <g>
                <g>
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    fill="#77CCDD"
                    d="M227.2,437.6h0.4h0.4h0.4h0.4h0.4c7.2-0.1,14.4-1.8,20.8-4.9
      c10.5-5.3,30.8-25.8,31.2-44.7v-1.1c-0.1-3.6-0.9-7.1-2.6-10.4c-7.4-13.9-34-20.7-56.1-20.9h-1.2c-4.2,0-8.1,0.3-11.7,0.7
      c-3.3,0.4-6.3,1-9.2,1.7c-1.5,13.8-2.4,26.8-1.1,40.9c1.3,13.5,3.6,22.1,6.3,33.2c6,3,12.7,4.8,19.8,5.2L227.2,437.6z"
                  />
                </g>
                <g>
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    fill="#77CCDD"
                    d="M366,438.8h-0.4h-0.4h-0.4h-0.4h-0.4
      c-7.2-0.1-14.4-1.8-20.8-4.9c-10.5-5.3-30.8-25.8-31.2-44.7v-1.1c0.1-3.6,0.9-7.1,2.6-10.4c7.4-13.9,34-20.7,56.1-20.9h1.2
      c4.2,0,8.1,0.3,11.7,0.7c3.3,0.4,6.3,1,9.2,1.7c1.5,13.8,2.4,26.8,1.1,40.9c-1.3,13.5-3.6,22.1-6.3,33.2c-6,3-12.7,4.8-19.8,5.2
      L366,438.8z"
                  />
                </g>
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  fill="#0763AE"
                  d="M296.6,364L296.6,364c-4.1,0-8.3-0.5-18.2-1.3
    c-10.1-0.9-20.9-3.5-23.5-4.4c-5-1.8-78.8-21.7-82,16.5c0,0-2.9,67.6,59.3,69.5c0,0,29,4.2,48.3-31.8c1.9-3.6,3.4-7.4,4.4-11.3
    c1.6-5.9,5.2-16.4,11.3-16.8v0c0.1,0,0.3,0,0.4,0h0h0h0h0h0h0h0c0.1,0,0.3,0,0.4,0v0c6.2,0.4,9.8,10.9,11.3,16.8
    c1,3.9,2.5,7.7,4.4,11.3c19.3,36,48.3,31.8,48.3,31.8c62.2-1.9,59.3-69.5,59.3-69.5c-3.3-38.3-77-18.3-82-16.5
    c-2.6,0.9-13.4,3.6-23.5,4.4C304.9,363.6,300.7,364,296.6,364L296.6,364z M380.4,361.2c19.7,2.6,29.4,8.6,29.5,25.3
    c0.1,25.1-19.8,46.5-45.4,47.9c-8.1,0.5-15.1-0.9-22.1-4.5c-11.8-6-37.1-31.5-26.6-51.2C322.8,365.6,366,359.3,380.4,361.2
    L380.4,361.2z M212.9,361.2c14.4-1.9,57.6,4.5,64.5,17.6c10.4,19.7-14.9,45.2-26.6,51.2c-7,3.5-14,4.9-22.1,4.5
    c-25.5-1.5-45.5-22.8-45.4-47.9C183.4,369.8,193.2,363.7,212.9,361.2z"
                />
              </g>
              <g>
                <g>
                  <g>
                    <path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      fill="#332C2B"
                      d="M270.6,438.5h55c0,0,1.7,29.1-29,29.1S270.6,438.5,270.6,438.5
        z"
                    />
                    <path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      fill="#F17072"
                      d="M275.3,459.1c0,0,3.5-4,21.2-4c17.7,0,22.1,4,22.1,4
        s-3.6,8.5-21.6,8.5C278.9,467.6,275.3,459.1,275.3,459.1z"
                    />
                  </g>
                </g>
                <g>
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    fill="#332C2B"
                    d="M274.9,403.1c0,8.2-6.6,14.8-14.8,14.8
      c-8.2,0-14.8-6.6-14.8-14.8c0-8.2,6.6-14.8,14.8-14.8C268.3,388.3,274.9,395,274.9,403.1z"
                  />
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    fill="#FFFFFF"
                    d="M260.7,396.7c0,4.8-3.9,8.7-8.7,8.7c-2.7,0-5.1-1.2-6.7-3.1
      c0-0.2,0-0.4,0-0.7c0-6.3,4.4-11.5,10.2-12.9C258.6,390.1,260.7,393.1,260.7,396.7z"
                  />
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    fill="#332C2B"
                    d="M378.7,403.1c0,8.2-6.6,14.8-14.8,14.8
      c-8.2,0-14.8-6.6-14.8-14.8c0-8.2,6.6-14.8,14.8-14.8C372,388.3,378.7,395,378.7,403.1z"
                  />
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    fill="#FFFFFF"
                    d="M364.5,396.7c0,4.8-3.9,8.7-8.7,8.7c-2.7,0-5.1-1.2-6.7-3.1
      c0-0.2,0-0.4,0-0.7c0-6.3,4.4-11.5,10.2-12.9C362.3,390.1,364.5,393.1,364.5,396.7z"
                  />
                </g>
              </g>
            </g>
            <g>
              <path
                fill="none"
                stroke="#079DD9"
                stroke-width="3.5"
                stroke-miterlimit="10"
                d="M321,464.2c27.1,3.3,76.6,9.2,81.4-31.4"
              />
              <g>
                <path
                  fill="#00567A"
                  d="M316,480.4c19.4,2.3,23-27.7,3.6-30.1C300.2,448,296.6,478.1,316,480.4L316,480.4z"
                />
              </g>
            </g>
            <g>
              <path
                fill="#2CB0E5"
                d="M436,96.2c0-1.2,0.1-2.4,0.3-3.8c0.3-6.3-0.3-13.1-2-20.6c-7.7-33.3-33.3-47.4-74.6-37.9
  c-41.3,9.5-58.1,33.5-50.4,66.8l2.1,9.2c1.4,6.3,9.2,9.8,17.3,7.9l10.7-2.5c8.1-1.9,13.5-8.5,12.1-14.7l-2.6-11.3
  c-3.4-14.9,3-22.3,16.5-25.4c13.5-3.1,22.5,0.7,26,15.6c12,51.7-33.4,66.6-22.9,112.1c0.1,0.6,0.3,1.3,0.5,1.9
  c1.6,6,9.3,9.3,17.2,7.5l9.2-2.1c8.2-1.9,13.5-8.6,12-14.9c0,0,0-0.1,0-0.1c-2.8-12.3,0.3-22.7,5.4-33c1.3-2.6,2.7-5.2,4.2-7.8
  C424.7,129.4,434.1,115.1,436,96.2z"
              />
              <path
                fill="#2CB0E5"
                d="M420.8,229.6l-1.4-6l-0.7-2.9c-1.4-6.3-9.2-9.8-17.3-7.9l-11.5,2.7c-8.1,1.9-13.5,8.5-12.1,14.7l2,8.9
  c1.4,6.3,9.2,9.8,17.3,7.9l11.5-2.7c4.1-1,7.6-3.1,9.8-5.9C420.5,235.8,421.5,232.6,420.8,229.6z"
              />
              <path
                fill="#056E8C"
                d="M418.5,238.4c2.1-2.6,3-5.8,2.3-8.8l-1.4-6l-0.7-2.9c-0.9-4-4.4-6.8-8.8-7.9c1.3,3.7,1.9,7.6,2,11.5
  c0,2.6-0.1,5.3-1.1,7.7c-1.3,3.2-3.8,5.7-6.7,7.6c-6,4.1-13.5,5.8-20.6,4.9c3.3,2.6,8.4,3.6,13.7,2.4l11.5-2.7
  C412.8,243.3,416.3,241.2,418.5,238.4z"
              />
              <path
                fill="#056E8C"
                d="M365.4,63.9c10.2-2.4,17.8-0.7,22.4,6.6c-1.1-2.2-2.4-4.4-3.8-6.4c-1.5-2.1-3.2-4.1-5.3-5.6
  c-4.3-3.1-10-3.7-15.3-3.2c-6.1,0.5-12.2,2.2-17.3,5.7c-5.1,3.5-9,8.9-9.9,14.9c-1.6,9.9,4.5,19.7,3.6,29.6
  c-0.4,3.9-1.9,7.6-4.3,10.7l4-0.9c8.1-1.9,13.5-8.5,12.1-14.7l-2.6-11.3C345.5,74.5,351.9,67,365.4,63.9z"
              />
              <path
                fill="#056E8C"
                d="M429.5,57.8c0,0.1,0,0.2,0,0.4c0.8,8.7,1.3,17.3,1.5,26c0.1,5.9,0.1,11.8-1.6,17.4c-1.5,4.7-4.1,9-6.8,13.1
  c-3.8,5.8-7.6,11.5-11.6,17.2c-7.1,10.1-14.9,20.5-16.7,32.7c-1.3,8.7,0.5,18-2.4,26.3c-1.3,3.8-3.5,7.1-6.1,10.2
  c0.2,0,0.4-0.1,0.5-0.1l9.2-2.1c8.2-1.9,13.5-8.6,12-14.9c0,0,0-0.1,0-0.1c-2.8-12.3,0.3-22.7,5.4-33c1.3-2.6,2.7-5.2,4.2-7.8
  c7.8-13.7,17.2-28,19.1-46.9c0-1.2,0.1-2.4,0.3-3.8c0.3-6.3-0.3-13.1-2-20.6C433.1,66.7,431.5,62,429.5,57.8z"
              />
            </g>
            <g>
              <circle fill="#CDE8F8" cx="160.7" cy="306.8" r="17.1" />
              <circle fill="#CDE8F8" cx="146.6" cy="245.6" r="11.5" />
              <circle fill="#CDE8F8" cx="187.7" cy="151" r="9.4" />
              <circle fill="#CDE8F8" cx="172.1" cy="122" r="7.3" />
              <circle fill="#CDE8F8" cx="171.2" cy="206.6" r="19.3" />
            </g>
          </svg>
        </div>
      </div>
      <div
        class="text-left mt-10 lg:w-4/5 w-full lg:text-base text-sm self-center"
      >
        <div
          class="pb-2 border-b flex justify-between cursor-pointer"
          onclick="showAnswer('question1')"
        >
          <div
            class="text-lg lg:text-xl leading-tight tracking-normal font-semibold self-center uppercase"
          >
            1. How to login?
          </div>
          <div class="border">
            <svg
              aria-hidden="true"
              class=""
              data-reactid="266"
              fill="none"
              height="24"
              stroke="#a0aec0"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              viewbox="0 0 24 24"
              width="24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2 hidden"
          id="question1"
        >
          Go to
          <a
            class="underline font-semibold"
            style="color:#0061af;"
            href="https://app.octosum.com/login"
            >https://app.octosum.com/login</a
          >
          and click register here. Follow the step of creating the account.
          Only valid official email id is accepted for registration. If you
          are from enterprise, please use purchasing entity. Select OEM or
          vendor if you would like to sell through the platform.
        </div>
        <div
          class="pb-2 border-b flex justify-between mt-16 cursor-pointer"
          onclick="showAnswer('question2')"
        >
          <div
            class="text-lg lg:text-xl leading-tight tracking-normal font-semibold self-center uppercase"
          >
            2. I am unable to login
          </div>
          <div class="border">
            <svg
              aria-hidden="true"
              class=""
              data-reactid="266"
              fill="none"
              height="24"
              stroke="#a0aec0"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              viewbox="0 0 24 24"
              width="24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2 hidden"
          id="question2"
        >
          If you have created an account recently then you will have to
          confirm the email address via the link sent to the mail id
          registered during the registration process. If still there is an
          issue with login please write to us at
          <a
            href="mailto:contact@octosum.com"
            class="underline font-semibold"
            style="color:#0061af;"
            >contact@octosum.com</a
          >
        </div>
        <div
          class="pb-2 border-b flex justify-between mt-16 cursor-pointer"
          onclick="showAnswer('question3')"
        >
          <div
            class="text-lg lg:text-xl leading-tight tracking-normal font-semibold self-center uppercase"
          >
            3. Forgot Password
          </div>
          <div class="border">
            <svg
              aria-hidden="true"
              class=""
              data-reactid="266"
              fill="none"
              height="24"
              stroke="#a0aec0"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              viewbox="0 0 24 24"
              width="24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2 hidden"
          id="question3"
        >
          Please click on the link forgot password and enter the company email
          address used for registration
        </div>
        <div
          class="pb-2 border-b flex justify-between mt-16 cursor-pointer"
          onclick="showAnswer('question4')"
        >
          <div
            class="text-lg lg:text-xl leading-tight tracking-normal font-semibold self-center uppercase"
          >
            4. What all browsers are supported
          </div>
          <div class="border">
            <svg
              aria-hidden="true"
              class=""
              data-reactid="266"
              fill="none"
              height="24"
              stroke="#a0aec0"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              viewbox="0 0 24 24"
              width="24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2 hidden"
          id="question4"
        >
          Chrome, Firefox, Opera, Internet explorer
        </div>
        <div
          class="pb-2 border-b flex justify-between mt-16 cursor-pointer"
          onclick="showAnswer('question5')"
        >
          <div
            class="text-lg lg:text-xl leading-tight tracking-normal font-semibold self-center uppercase"
          >
            5. I am unable to open the website
          </div>
          <div class="border">
            <svg
              aria-hidden="true"
              class=""
              data-reactid="266"
              fill="none"
              height="24"
              stroke="#a0aec0"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              viewbox="0 0 24 24"
              width="24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2 hidden"
          id="question5"
        >
          Please delete the cookies and temporary file and retry
        </div>
        <div
          class="pb-2 border-b flex justify-between mt-16 cursor-pointer"
          onclick="showAnswer('question6')"
        >
          <div
            class="text-lg lg:text-xl leading-tight tracking-normal font-semibold self-center uppercase"
          >
            6. Customer Support
          </div>
          <div class="border">
            <svg
              aria-hidden="true"
              class=""
              data-reactid="266"
              fill="none"
              height="24"
              stroke="#a0aec0"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              viewbox="0 0 24 24"
              width="24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2 hidden"
          id="question6"
        >
          <a
            href="mailto:contact@octosum.com"
            class="underline font-semibold"
            style="color:#0061af;"
            >contact@octosum.com</a
          >,
          <a
            href="mailto:info@octosum.com"
            class="underline font-semibold"
            style="color:#0061af;"
            >info@octosum.com</a
          >
        </div>
        <div
          class="pb-2 border-b flex justify-between mt-16 cursor-pointer"
          onclick="showAnswer('question7')"
        >
          <div
            class="text-lg lg:text-xl leading-tight tracking-normal font-semibold self-center uppercase"
          >
            7. Can I generate product subscription without PO
          </div>
          <div class="border">
            <svg
              aria-hidden="true"
              class=""
              data-reactid="266"
              fill="none"
              height="24"
              stroke="#a0aec0"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              viewbox="0 0 24 24"
              width="24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>
        <div
          class="text-left text-sm lg:text-xl leading-tight tracking-normal mt-2 hidden"
          id="question7"
        >
          Yes. You need to upload the Old data in excel format
        </div>
      </div>
    </div>
  </div>
</div>
  
@endsection


@push('post-scripts')

<script>
function showAnswer(qid) {
    let element = document.getElementById(qid);
    if (element.classList.contains("hidden")) {
        element.classList.remove("hidden");
        element.classList.add("block");
    } else {
        element.classList.remove("block");
        element.classList.add("hidden");
    }
}
</script>

@endpush