@extends('active.master')

@section('metadesc'){{ 'Cookies -' . $data->ref->site->title  }}@endsection

@section('metakeys'){{ 'cookies, policy' }}@endsection

@push('headers')
<link rel="canonical" href="{{ url('cookies') }}">
@endpush


@section('contents')

<div style="background: #e7fbff;">
	<div class="container px-6 mx-auto flex flex-col py-6">
		<div class="flex flex-col p-10">
			<div class="text-left">
				<h1
					class=" text-xl  lg:text-4xl leading-tight tracking-normal font-bold self-center"
					style="color:#0061af;"
				>
					Octosum Policies, Cookies, Terms & Legal Stuff
				</h1>
			</div>
			<div
				class="mt-10 text-lg lg:text-xl leading-tight font-semibold tracking-normal text-gray-800"
			>
				<ul class="list-inside list-disc">
					<li>
						<a
							href="{{ url('privacy') }}"
							class="border-b-2 border-gray-800 hover:border-vendor-500"
						>
							Privacy
						</a>
					</li>
					<li class="mt-4">
						<a
							href="{{ url('cookies') }}"
							class="border-b-2 border-gray-800 hover:border-vendor-500"
						>
							Cookies
						</a>
					</li>
				</ul>
			</div>
			<div class="mt-10">
				<div class="flex flex-col">
					<div>
					<h1
							class=" text-xl  lg:text-4xl leading-tight tracking-normal font-bold self-center"
							style="color:#0061af;"
					>
							Cookie Usage Statement
					</h1>
					</div>
					<div
					class="flex flex-col mt-6 text-left text-sm lg:text-xl leading-tight tracking-normal text-gray-700"
					>
					<p>
							This website uses cookies. By using the website and agreeing to this
							policy, you consent to our use of cookies in accordance with the terms
							of this policy.
					</p>
					<p class="mt-4 uppercase font-semibold">
							ABOUT COOKIES
					</p>
					<p class="mt-4">
							Cookies are files, often including unique identifiers, that are sent by
							web servers to web browsers, and which may then be sent back to the
							server each time the browser requests a page from the server.
					</p>
					<p class="mt-4">
							Cookies can be used by web servers to identity and track users as they
							navigate different pages on a website, and to identify users returning
							to a website.
					</p>
					<p class="mt-4">
							Cookies may be either “persistent” cookies or “session” cookies. A
							persistent cookie consists of a text file sent by a web server to a web
							browser, which will be stored by the browser and will remain valid until
							its set expiry date (unless deleted by the user before the expiry date).
							A session cookie, on the other hand, will expire at the end of the user
							session, when the web browser is closed.
					</p>
					<p class="mt-4 uppercase font-semibold">
							COOKIES ON THE WEBSITE
					</p>
					<p class="mt-4">
							We use both session cookies and persistent cookies on the website.
					</p>
					<p class="mt-4 uppercase font-semibold">
							HOW WE USE COOKIES
					</p>
					<p class="mt-4">
							Cookies do not contain any information that personally identifies you,
							but personal information that we store about you may be linked, by us,
							to the information stored in and obtained from cookies. The cookies used
							on the website include those which are strictly necessary cookies for
							access and navigation, cookies that track usage (performance cookies),
							remember your choices (functionality cookies), and cookies that provide
							you with targeted content or advertising
					</p>
					<p class="mt-4">
							We may use the information we obtain from your use of our cookies for
							the following purposes:
					</p>
					<div class="mt-4">
							<ul class="list-inside list-decimal">
							<li class="mt-2">
									to recognise your computer when you visit the website
							</li>
							<li class="mt-2">
									to track you as you navigate the website, and to enable the use of
									any e-commerce facilities
							</li>
							<li class="mt-2">to improve the website’s usability</li>
							<li class="mt-2">to analyse the use of the website</li>
							<li class="mt-2">in the administration of the website</li>
							<li class="mt-2">
									to personalise the website for you, including targeting
									advertisements which may be of particular interest to you.
							</li>
							</ul>
					</div>
					<p class="mt-4 uppercase font-semibold">
							THIRD PARTY COOKIES
					</p>
					<p class="mt-4">
							When you use the website, you may also be sent third party cookies.
					</p>
					<p class="mt-4">
							Our advertisers and service providers may send you cookies. They may use
							the information they obtain from your use of their cookies:
					</p>
					<div class="mt-4">
							<ul class="list-inside list-decimal">
							<li class="mt-2">
									to track your browser across multiple websites
							</li>
							<li class="mt-2">
									to build a profile of your web surfing
							</li>
							<li class="mt-2">
									to target advertisements which may be of particular interest to you.
							</li>
							</ul>
					</div>
					<p class="mt-4 font-semibold">
							BLOCKING COOKIES
					</p>
					<p class="mt-4">
							Most browsers allow you to refuse to accept cookies. For example:
					</p>
					<div class="mt-4">
							<ul class="list-inside list-decimal">
							<li class="mt-2">
									in Internet Explorer you can refuse all cookies by clicking “Tools”,
									“Internet Options”, “Privacy”, and selecting “Block all cookies”
									using the sliding selector.
							</li>
							<li class="mt-2">
									in Firefox you can block all cookies by clicking “Tools”, “Options”,
									and un-checking “Accept cookies from sites” in the “Privacy” box.
							</li>
							<li class="mt-2">
									in Google Chrome you can adjust your cookie permissions by clicking
									“Options”, “Under the hood”, Content Settings in the “Privacy”
									section. Click on the Cookies tab in the Content Settings.
							</li>
							<li class="mt-2">
									in Safari you can block cookies by clicking “Preferences”, selecting
									the “Privacy” tab and “Block cookies”.
							</li>
							</ul>
					</div>
					<p class="mt-4">
							Blocking all cookies will, however, have a negative impact upon the
							usability of many websites. If you block cookies, you may not be able to
							use certain features on the website (log on, access content, use search
							functions).
					</p>
					<p class="mt-4 font-semibold">
							DELETING COOKIES
					</p>
					<p class="mt-4">
							You can also delete cookies already stored on your computer:
					</p>
					<div class="mt-4">
							<ul class="list-inside list-decimal">
							<li class="mt-2">
									in Internet Explorer, you must manually delete cookie files.
							</li>
							<li class="mt-2">
									in Firefox, you can delete cookies by, first ensuring that cookies
									are to be deleted when you “clear private data” (this setting can be
									changed by clicking “Tools”, “Options” and “Settings” in the
									“Private Data” box) and then clicking “Clear private data” in the
									“Tools” menu.
							</li>
							<li class="mt-2">
									in Google Chrome you can adjust your cookie permissions by clicking
									“Options”, “Under the hood”, Content Settings in the “Privacy”
									section. Click on the Cookies tab in the Content Settings.
							</li>
							<li class="mt-2">
									in Safari you can delete cookies by clicking “Preferences”,
									selecting the “Privacy” tab and “Remove All Website Data”.
							</li>
							</ul>
					</div>
					<p class="mt-4">
							Obviously, doing this may have a negative impact on the usability of
							many websites.
					</p>
					</div>
			</div>
			</div>
		</div>
	</div>
</div>
  
@endsection