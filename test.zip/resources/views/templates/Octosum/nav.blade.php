<div>
  <nav
    id="header"
    class="px-4 md:px-32 py-6 flex items-center justify-between flex-wrap border-b border-gray-300 shadow-md "
  >
    <div class="flex items-center flex-shrink-0 text-white mr-6">
      <a href="/"
        class="no-underline hover:no-underline font-bold text-2xl lg:text-4xl"
      >
        <img class="h-10 fill-current inline" src="/storage/media/EZsC9AnqoS05SCZLYGOwgTm78YiuEa7goImma5Nu.png" />
      </a>
    </div>
    <div class="block lg:hidden">
      <button
        id="nav-toggle"
        onclick="navToggle()"
        class="flex items-center px-3 py-2 border rounded border-white appearance-none focus:outline-none"
      >
        <svg
          class="fill-current h-3 w-3"
          viewBox="0 0 20 20"
          xmlns="http://www.w3.org/2000/svg"
        >
          <title>Menu</title>
          <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
        </svg>
      </button>
    </div>
    <div
      id="nav-content"
      class="w-full block flex-grow lg:flex-grow-0 lg:flex lg:items-center lg:content-end lg:w-auto mt-4 lg:mt-0"
    >
      <div class="lg:flex lg:flex-grow">
        <div>
          <a
            href="{{ url('/') . '#enterprise' }}"
            onclick="showEnterprise()"
            class="inline-block no-underline hover:font-bold hover:underline py-2 px-4"
            >Enterprise</a
          >
        </div>
        <div>
          <a
            href="{{ url('/') . '#vendor' }}"
            onclick="showVendor()"
            class="inline-block no-underline hover:font-bold hover:underline py-2 px-4"
            >Vendor</a
          >
        </div>
        <div>
          <a
            href="{{ url('/') . '#contact' }}"
            class="inline-block no-underline hover:font-bold hover:underline py-2 px-4"
            >Contact</a
          >
        </div>
        
        @guest
        <div>
          <a
            href="https://app.octosum.com/register"
            class="inline-block no-underline hover:font-bold hover:underline py-2 px-4"
            >Free Trial</a
          >
        </div>
        @endguest
        
        
        <div>
          @auth
          <a
            href="javascript:void(0)"
            @click="logout"
            id="logout"
            class="inline-block no-underline hover:font-bold hover:underline py-2 px-4 lg:rounded-full lg:text-black lg:border lg:outline-none"
            style="background-color: #bae314; border-color: #bae314"
            >Logout</a
          >
          @endauth
          
          @guest
          <a
            href="https://app.octosum.com/login"
            id="navAction"
            class="inline-block no-underline hover:font-bold hover:underline py-2 px-4 lg:rounded-full lg:text-black lg:border lg:outline-none"
            style="background-color: #bae314; border-color: #bae314"
            >Login</a
          >
          @endguest
        </div>
      </div>
    </div>
  </nav>
</div>