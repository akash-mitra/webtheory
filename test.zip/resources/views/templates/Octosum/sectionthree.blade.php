<div>
  <div>
    <svg
      class="fill-currrent w-full"
      version="1.1"
      id="Layer_1"
      xmlns="http://www.w3.org/2000/svg"
      xmlns:xlink="http://www.w3.org/1999/xlink"
      x="0px"
      y="0px"
      viewBox="0 0 1885 166"
      enable-background="new 0 0 1885 166"
      xml:space="preserve"
    >
      <g>
        <linearGradient
          id="SVGID_1_"
          gradientUnits="userSpaceOnUse"
          x1="-15.5037"
          y1="76.4309"
          x2="1896.3022"
          y2="76.4309"
        >
          <stop offset="0" style="stop-color:#B0ECF6" />
          <stop offset="1" style="stop-color:#87F1F6" />
        </linearGradient>
        <path
          fill="url(#SVGID_1_)"
          d="M1896.3,60.8c-251,35-370,18.8-517-27.3c-147.1-46.1-235-19.2-405.6,40.9
  c-170.6,60.1-405.4-41.8-581.9-41.8c-176.5,0-282.6,61.1-407.4,61.1v49h1911.1L1896.3,60.8z"
        />
        <linearGradient
          id="SVGID_2_"
          gradientUnits="userSpaceOnUse"
          x1="-12.806"
          y1="85.4234"
          x2="1899"
          y2="85.4234"
        >
          <stop offset="0" style="stop-color:#CDF2FF" />
          <stop offset="1" style="stop-color:#88FCFF" />
        </linearGradient>
        <path
          fill="url(#SVGID_2_)"
          d="M1899,69.8c-251,35-370,18.8-517-27.3c-147.1-46.1-235-19.2-405.6,40.9
  C805.8,143.5,571,41.6,394.5,41.6c-176.5,0-282.6,61.1-407.4,61.1v49h1911.1L1899,69.8z"
        />
        <path
          fill="#E7FBFF"
          d="M1891.8,87.8c-251,35-370,18.8-517-27.3c-147.1-46.1-235-19.2-405.6,40.9
  c-170.6,60.1-405.4-41.8-581.9-41.8c-176.5,0-282.6,61.1-407.4,61.1v49h1911.1L1891.8,87.8z"
        />
      </g>
    </svg>
  </div>
  <div
    class="px-8 lg:px-32 md:py-16 mx-auto flex flex-col md:flex-row justify-between "
    style="background: #e7fbff;"
  >
    <!--Left Col-->
    <div
      class="flex flex-col w-full lg:w-2/5 justify-center items-start text-center md:text-left"
    >
      <div class="my-6 self-start">
        <p
          class="text-xl lg:text-4xl leading-tight tracking-normal font-bold"
          style="color:#0061af;"
        >
          Here’s how it works
        </p>
      </div>
      <div class="mb-6 self-start">
        <a
          href="https://app.octosum.com"
          class="text-black py-2 px-6 border rounded outline-none uppercase text-xl leading-tight tracking-wide font-semibold hover:text-white"
          style="background-color: #bae314; border-color: #bae314"
          >Get Started</a
        >
      </div>
    </div>
    <!--Right Col-->
    <div class="lg:w-3/5 pb-10">
      <div class="videoWrapper">
        <!-- Copy & Pasted from YouTube -->
        <iframe
          width="560"
          height="300"
          src="https://www.youtube.com/embed/XtMbKxWdz64?rel=0&hd=1"
          frameborder="0"
          allowfullscreen
        ></iframe>
      </div>
    </div>
  </div>
  <div class="lg:-mt-16 -mt-6">
    <svg
      class="fill-current w-full"
      version="1.1"
      id="Layer_1"
      xmlns="http://www.w3.org/2000/svg"
      xmlns:xlink="http://www.w3.org/1999/xlink"
      x="0px"
      y="0px"
      viewBox="0 0 1885 195"
      enable-background="new 0 0 1885 195"
      xml:space="preserve"
    >
      <g>
        <linearGradient
          id="SVGID_1_"
          gradientUnits="userSpaceOnUse"
          x1="-16.1919"
          y1="102.2131"
          x2="1930.9227"
          y2="102.2131"
        >
          <stop offset="0" style="stop-color:#B0ECF6" />
          <stop offset="1" style="stop-color:#87F1F6" />
        </linearGradient>
        <path
          fill="url(#SVGID_1_)"
          d="M-15.9,72.4C30.2,47.1,102,16.2,188.3,18c90.4,1.9,112.2,37.1,218.3,45.1
  C518,71.6,532.5,35.3,649.3,38.9C783.7,43,790.1,91.6,902.1,91.3c138.2-0.4,157.7-74.6,293.6-75.2c125.5-0.6,138.8,62.5,263,59.5
  c123-2.9,154.9-65.9,274.8-66.6c86.9-0.5,155.8,32,197.4,56.7v129.7H-16.2L-15.9,72.4z"
        />
        <linearGradient
          id="SVGID_2_"
          gradientUnits="userSpaceOnUse"
          x1="-36.0001"
          y1="119.4665"
          x2="1912.8776"
          y2="119.4665"
        >
          <stop offset="0" style="stop-color:#CDF2FF" />
          <stop offset="1" style="stop-color:#88FCFF" />
        </linearGradient>
        <path
          fill="url(#SVGID_2_)"
          d="M-36,55.9c59.8,32.2,142.2,65.7,233.3,56.7c90.7-9,105.4-52,193.1-58.4c122.3-9,154.3,70,282.3,68.2
  c115.7-1.6,124.1-66.6,246.5-72.6c128.9-6.3,153.7,64.2,290.1,61.2c123.8-2.8,131.9-61.5,250.3-59.7
  c118.8,1.8,152.8,61.5,273.3,61.2c78.3-0.2,140.9-25.6,179.9-45.5v122.5H-36V55.9z"
        />
        <path
          fill="#FFFFFF"
          d="M-34,160.9c46.1-25.3,117.9-56.2,204.2-54.4c90.4,1.9,112.2,37.1,218.3,45.1
  c111.3,8.4,125.9-27.8,242.7-24.2c134.4,4.1,140.8,52.7,252.8,52.4c138.2-0.4,157.7-74.6,293.6-75.2c125.5-0.6,138.8,62.5,263,59.5
  c123-2.9,154.9-65.9,274.8-66.6c86.9-0.5,155.8,32,197.4,56.7V209H-34.2L-34,160.9z"
        />
      </g>
    </svg>
  </div>
</div>