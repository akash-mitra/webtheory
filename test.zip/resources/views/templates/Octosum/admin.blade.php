@extends('active.master')

@section('metadesc'){{ 'Admin Login -' . $data->ref->site->title  }}@endsection

@section('metakeys'){{ 'admin, admin login, admin panel' }}@endsection

@push('headers')
<link rel="canonical" href="{{ url('admin') }}">
@endpush


@section('contents')

<div style="background: #e7fbff;">
	<div
		class="container mx-auto h-full flex flex-col justify-center items-center pt-8"
	>
		<div class="flex flex-col mt-10">
			<p class="text-3xl lg:text-4xl text-gray-700 font-bold uppercase">
				Admin Login
			</p>
			<p class="text-gray self-center">Manage your Site</p>
		</div>    
		<div>
			<div class="w-full flex items-center justify-between pb-8 pt-10">
				@include('active.user-menu')
			</div>
		</div>
	</div>
</div>

@endsection
