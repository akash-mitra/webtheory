<div class="flex flex-col items-center mt-4">
  <div
    class="text-xl px-8 pt-10 lg:text-4xl leading-tight tracking-normal font-bold text-center self-center"
    style="color:#0061af;"
  >
    Octosum is awesome if you’re
  </div>
  
  <div class="mt-8 w-4/5 md:px-16 flex justify-center z-10">
    <div class="w-full md:px-16 flex justify-center border-b border-gray-500">
      <div role="tablist" class="vue-tablist">
        <li
          id="enterprise"
          ref="enterprise"
          role="tab"
          aria-disabled="false"
          aria-selected="true"
          aria-controls="enterprise-panel"
          tabindex="0"
          class="vue-tab md:mx-10 md:text-2xl text-xl"
          onclick="showEnterprise()"
        >
          Enterprise
        </li>
        <li
          id="vendor"  
          ref="vendor"
          role="tab"
          aria-disabled="false"
          aria-selected="false"
          aria-controls="vendor-panel" 
          tabindex="-1"
          class="vue-tab md:mx-10 md:text-2xl text-xl opacity-25"
          onclick="showVendor()"
        >
          Vendor
        </li>
      </div>
    </div>
  </div>
    
  
  
  
  <div class="mt-8 flex flex-col justify-center w-full md:px-16 z-10">
      
    <div
      id="enterprise-panel"
      role="tabpanel"
      tabindex="0"
      aria-labelledby="enterprise"
      class="flex flex-col justify-center md:px-16 w-full"
    >
      <div
        class="mt-6 px-8 text-xl md:text-4xl leading-tight tracking-wide font-bold text-center self-center w-full"
      >
        Get more value out of your Enterprise Subscriptions. <br />
        Save smart.
      </div>
      <div class="mt-8 flex flex-col w-full px-8">
        <div class="flex flex-col-reverse lg:flex-row justify-between my-6">
          <div class="flex self-center flex-col lg:flex-grow">
            <div class="flex flex-col lg:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center font-bold"
                  style="background-color: #bae314; border-color: #bae314"
                  >1</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg md:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left "
              >
                Optimize your subscription utilization
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg  md:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              View the number of subscriptions deployed and available for
              deployment through customized dashboards. No more under-utilized
              subscriptions.
            </div>
          </div>
          <div
            class="flex py-6 lg:py-0 lg:justify-end justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/enterprise-01.svg"
            />
          </div>
        </div>
        <div class="flex flex-col lg:flex-row justify-between my-6">
          <div
            class="flex py-6 lg:py-0 lg:justify-start justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/enterprise-02.svg"
            />
          </div>
          <div class="flex self-center flex-col lg:flex-grow lg:ml-6">
            <div class="flex flex-col md:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center bg-button-500 border border-button-500 font-bold"
                  style="background-color: #bae314; border-color: #bae314"
                  >2</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg lg:text-xl leading-tight tracking-wide font-semibold text-center"
              >
                Manage allocations of subscriptions to projects
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg lg:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Visibility of all allocated subscriptions gives ease of
              allocating or re-allocating as per project requirements. Easy
              resource management.
            </div>
          </div>
        </div>
        <div class="flex flex-col-reverse lg:flex-row justify-between my-6">
          <div class="flex self-center flex-col lg:flex-grow">
            <div class="flex flex-col lg:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center font-bold"
                  style="background-color: #bae314; border-color: #bae314"
                  >3</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg md:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left "
              >
                Take control of renewals in time, every time
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg  md:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Calendarized view of upcoming renewals to plan budget cycle and
              evaluate usage of subscriptions. Better planning, better
              decisions.
            </div>
          </div>
          <div
            class="flex py-6 lg:py-0 lg:justify-end justify-center lg:w-1/2"
          >
            <img
              class="w-full h-auto"
              src="/media/enterprise-03.svg"
            />
          </div>
        </div>
        <div class="flex flex-col lg:flex-row justify-between my-6">
          <div
            class="flex py-6 lg:py-0 lg:justify-start justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/enterprise-04.svg"
            />
          </div>
          <div class="flex self-center flex-col lg:flex-grow lg:ml-6">
            <div class="flex flex-col md:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center font-bold"
                  style="background-color: #bae314; border-color: #bae314"
                  >4</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg lg:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left"
              >
                Bring your Procurement, Compliance, IT and Business teams on a
                unified platform
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg lg:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              End-to-end visibility across business units for increased
              productivity and ease in subscription lifecycle. Unified
              platform for unified teams.
            </div>
          </div>
        </div>
        <div class="flex flex-col-reverse lg:flex-row justify-between my-6">
          <div class="flex self-center flex-col lg:flex-grow">
            <div class="flex flex-col lg:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center font-bold"
                  style="background-color: #bae314; border-color: #bae314"
                  >5</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg md:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left "
              >
                Get real-time analytics and insights
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg  md:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Real-time reporting helps in better planning and decision making
              of available resources. Actionable insights for diligent usage.
            </div>
          </div>
          <div
            class="flex py-6 lg:py-0 lg:justify-end justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/enterprise-05.svg"
            />
          </div>
        </div>
        <div class="flex flex-col lg:flex-row justify-between my-6">
          <div
            class="flex py-6 lg:py-0 lg:justify-start justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/enterprise-06.svg"
            />
          </div>
          <div class="flex self-center flex-col lg:flex-grow lg:ml-6">
            <div class="flex flex-col md:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center font-bold"
                  style="background-color: #bae314; border-color: #bae314"
                  >6</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg lg:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left"
              >
                Handle vendor engagement efficiently
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg lg:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Pre-loaded NDAs and Contracts helps in effective vendor
              management and faster turn-around time. Reduce your process
              lifecycle.
            </div>
          </div>
        </div>
        <div class="flex flex-col-reverse lg:flex-row justify-between my-6">
          <div class="flex self-center flex-col lg:flex-grow">
            <div class="flex flex-col lg:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center font-bold"
                  style="background-color: #bae314; border-color: #bae314"
                  >7</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg md:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left "
              >
                Stay compliant, minimize risks
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg  md:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Track over-utilized and overdue subscriptions to keep your
              business compliant. Minimize risks.
            </div>
          </div>
          <div
            class="flex py-6 lg:py-0 lg:justify-end justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/enterprise-07.svg"
            />
          </div>
        </div>
        <div class="flex flex-col lg:flex-row justify-between my-6">
          <div
            class="flex py-6 lg:py-0 lg:justify-start justify-center lg:w-2/5"
          >
            <img
              class="w-64 h-auto"
              src="/media/enterprise-08.svg"
            />
          </div>
          <div class="flex self-center flex-col lg:flex-grow lg:ml-6">
            <div class="flex flex-col md:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center font-bold"
                  style="background-color: #bae314; border-color: #bae314"
                  >8</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg lg:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left"
              >
                Get access to vendor marketplace
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg lg:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Access to directory of multiple vendors listed by technology and
              services. Ease the process of procurement.
            </div>
          </div>
        </div>
      </div>
      <div class="my-8 flex flex-col justify-center self-center">
        <div class="mb-6 self-center">
          <a
            href="https://app.octosum.com"
            class="text-black py-2 px-6 border rounded outline-none uppercase text-xl leading-tight tracking-wide font-semibold hover:text-white"
            style="background-color: #46bbd9; border-color: #46bbd9"
            >Free Trial
          </a>
        </div>
        <div class=" self-center text-base font-semibold ">
          <p>Enterprise users - Free for 60 days</p>
        </div>
        <div class="self-center italic">
          *No obligations, no credit card required
        </div>
        <div class="self-center italic">
          Full features available
        </div>
      </div>
    </div>
    
    
    
    <div
      id="vendor-panel"
      role="tabpanel"
      tabindex="0"
      aria-labelledby="vendor"
      class="flex flex-col justify-center md:px-16"
      style="display: none;"
    >
      <div
        class="mt-6 px-8 text-xl md:text-4xl leading-tight tracking-wide font-bold text-center self-center"
      >
        Manage Subscription sales efficiently. <br />
        Grow your business
      </div>
      <div class="mt-8 flex flex-col w-full px-8">
        <div class="flex flex-col-reverse lg:flex-row justify-between my-6">
          <div class="flex self-center flex-col lg:flex-grow">
            <div class="flex flex-col lg:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center border font-bold text-white"
                  style="background-color: #46bbd9; border-color: #46bbd9"
                  >1</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg md:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left "
              >
                Get listed on marketplace. Get higher visibility.
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg  md:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Get connected to a larger customer base and get spotted based on
              your services and technology competencies. Scale your business.
            </div>
          </div>
          <div
            class="flex py-6 lg:py-0 lg:justify-end justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/vendor-1.svg"
            />
          </div>
        </div>
        <div class="flex flex-col lg:flex-row justify-between my-6">
          <div
            class="flex py-6 lg:py-0 lg:justify-start justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/vendor-2.svg"
            />
          </div>
          <div class="flex self-center flex-col lg:flex-grow lg:ml-6">
            <div class="flex flex-col md:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center border font-bold text-white"
                  style="background-color: #46bbd9; border-color: #46bbd9"
                  >2</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg lg:text-xl leading-tight tracking-wide font-semibold text-center"
              >
                Interact with enterprise customers on a single platform
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg lg:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Be connected with multiple customers and keep a track of all
              sales - get notified by the customer, make quicker quotations
              and invoices. Make processes simpler.
            </div>
          </div>
        </div>
        <div class="flex flex-col-reverse lg:flex-row justify-between my-6">
          <div class="flex self-center flex-col lg:flex-grow">
            <div class="flex flex-col lg:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center border font-bold text-white"
                  style="background-color: #46bbd9; border-color: #46bbd9"
                  >3</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg md:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left "
              >
                Improve your renewal rate. Never miss a renewal.
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg  md:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Reports and analytics for better business continunity from
              existing customers. Ensure repetative business, in a timely
              manner.
            </div>
          </div>
          <div
            class="flex py-6 lg:py-0 lg:justify-end justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/vendor-3.svg"
            />
          </div>
        </div>
        <div class="flex flex-col lg:flex-row justify-between my-6">
          <div
            class="flex py-6 lg:py-0 lg:justify-start justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/vendor-4.svg"
            />
          </div>
          <div class="flex self-center flex-col lg:flex-grow lg:ml-6">
            <div class="flex flex-col md:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center border font-bold text-white"
                  style="background-color: #46bbd9; border-color: #46bbd9"
                  >4</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg lg:text-xl leading-tight tracking-wide font-semibold text-center"
              >
                Visibility of all sold subscriptions, customer-wise
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg lg:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Track all your subscription sales in one place. Track
              subscription renewals and ensure effective sales. Increase team
              efficiency.
            </div>
          </div>
        </div>
        <div class="flex flex-col-reverse lg:flex-row justify-between my-6">
          <div class="flex self-center flex-col lg:flex-grow">
            <div class="flex flex-col lg:flex-row">
              <div class="self-center">
                <span
                  class="rounded-full h-8 w-8 flex items-center justify-center border font-bold text-white"
                  style="background-color: #46bbd9; border-color: #46bbd9"
                  >5</span
                >
              </div>
              <div
                class="ml-2 self-center text-lg md:text-xl leading-tight tracking-wide font-semibold text-center lg:text-left "
              >
                Manage Subscription Certificates
              </div>
            </div>
            <div
              class="mt-2 self-start text-lg  md:text-xl leading-tight tracking-wide text-center lg:text-left"
            >
              Organize all sold subscriptions, customer-wise on a single
              platform. Certificates can be shared with your customer via
              platform. Achieve operational excellence.
            </div>
          </div>
          <div
            class="flex py-6 lg:py-0 lg:justify-end justify-center lg:w-1/2"
          >
            <img
              class="w-64 h-auto"
              src="/media/vendor-5.svg"
            />
          </div>
        </div>
      </div>
      <div class="my-8 flex flex-col justify-center self-center">
        <div class="mb-6 self-center">
          <a
            href="https://app.octosum.com"
            class="text-black py-2 px-6 border rounded outline-none uppercase text-xl leading-tight tracking-wide font-semibold hover:text-white"
            style="background-color: #bae314; border-color: #bae314"
            >Get Started</a
          >
        </div>
        <div class=" self-center text-base font-semibold ">
          <p>Vendors/Resellers - Get listed for free</p>
        </div>
        <div class="self-center italic">
          <p>*Premium features for 60-days</p>
        </div>
      </div>
    </div>
    
      
  </div>


</div>