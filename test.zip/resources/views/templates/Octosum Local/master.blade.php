<!doctype html>
<html lang="en-us">

<head>
  <meta charset="utf-8">

  <title>@yield('title')</title>

  <meta name="description" content="@yield('metadesc')">

  <meta name="keywords" content="@yield('metakeys')">

  <meta name="generator" content="webtheory">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <meta name="theme-color" content="#fafafa">

  <link href="/css/serenity.{{$data->ref->template->primaryColor}}.css" rel="stylesheet">
  {{-- <link href="/css/style.css" rel="stylesheet"> --}}

  @favicon



  @if(!empty(optional($data->ref->template)->headingFont))
    <link href="https://fonts.googleapis.com/css?family={{ str_replace(' ', '+', $data->ref->template->headingFont) }}&display=swap" rel="stylesheet">
    <style>
        h1, h2, h3, h4, h5, h6 {
            font-family: "{{ $data->ref->template->headingFont }}", serif;
        }
    </style>
  @else
    <style>
        h1, h2, h3, h4, h5, h6 {
            font-family: serif;
        }
    </style>
  @endif

  @if(!empty(optional($data->ref->template)->readingFont))
    <link href="https://fonts.googleapis.com/css?family={{ str_replace(' ', '+', $data->ref->template->readingFont) }}&display=swap" rel="stylesheet">
    <style>
        p {
            font-family: "{{ $data->ref->template->readingFont }}", sans-serif;
        }
    </style>
  @else
    <link href="https://fonts.googleapis.com/css?family=Quicksand&display=swap" rel="stylesheet">
    <style>
        p {
            font-family: Quicksand, sans-serif;
        }
    </style>
  @endif

  <link href="https://fonts.googleapis.com/css?family=Noto+Sans&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
  
  @stack('styles')

  @stack('headers')

</head>

<body onload="check()">

    <div style="width: 100%; height: 100%; margin: 0; padding: 0;"
        id="js-playground"
        v-cloak
        @click="discardModalsAndPopups"
        @keydown.esc="discardModalsAndPopups"
    >

        @include('active.nav')
        
        @yield('contents')
        
        @include('active.footer')

        <form method="post" action="/logout" id="loform" ref="loform">@csrf</form>
    </div>

    {{-- <script src="https://cdn.jsdelivr.net/npm/vue@2.6.11"></script> --}}
    {{-- <script src="https://vuejs.org/js/vue.js"></script> --}}

    <script src="{{ mix('/js/frontend.js') }}"></script>

    <script>
        window.csrf_token="{{ csrf_token() }}"
    </script>

    @stack('pre-scripts')
    

    <script>
        const v = new Vue({

            el: '#js-playground',

            data: {

                @if(empty(old('loginFormType') ))
                isLoginModalOpen: false,
                @else
                isLoginModalOpen: true,
                @endif

                @switch(old('loginFormType'))
                    @case('registration')
                        mode: 'signup',
                    @break
                    @case('forgot')
                        mode: 'forgot',
                    @break
                    @default
                        mode: 'login',
                @endswitch

                isUserMenuOpen: false,

                authuser: @json($data->user),

            },

            methods: {
                discardModalsAndPopups() {
                    this.isUserMenuOpen = this.isLoginModalOpen = false
                },

                logout() {
                    this.$refs.loform.submit()
                }
            }
        });
    </script>
    
    <script>
        function navToogle() {
          var x = document.getElementById("nav-content");
          if (x.style.display === "none") {
            x.style.display = "block";
          } else {
            x.style.display = "none";
          }
        }
    </script>

    <script>
        function showEnterprise() {
            // console.log('enterprise');
            document.getElementById('enterprise').setAttribute('aria-selected', true);
            document.getElementById('vendor').setAttribute('aria-selected', false);
            document.getElementById('enterprise').classList.remove("opacity-25");
            document.getElementById('vendor').classList.add("opacity-25");
        
            document.getElementById('enterprise-panel').style.display = "block";
            document.getElementById('vendor-panel').style.display = "none";
        }
    
        function showVendor() {
            // console.log('vendor');
            document.getElementById('enterprise').setAttribute('aria-selected', false);
            document.getElementById('vendor').setAttribute('aria-selected', true);
            document.getElementById('enterprise').classList.add("opacity-25");
            document.getElementById('vendor').classList.remove("opacity-25");
        
            document.getElementById('enterprise-panel').style.display = "none";
            document.getElementById('vendor-panel').style.display = "block";
        }

        function check() {
            if (window.location.hash.indexOf("enterprise") != -1) 
                showEnterprise();
                
            if (window.location.hash.indexOf("vendor") != -1) 
                showVendor();
        }
        
        function selectedSlide(sid) {
            // console.log(sid);
            
            for (var i = 1; i < 8; i++) {
                let title = document.getElementById('mediaTitle' + i);
                title.classList.add("hidden");
                let desc = document.getElementById('mediaDesc' + i);
                desc.classList.add("hidden");
                let image = document.getElementById('mediaImage' + i);
                image.classList.add("hidden");
                let button = document.getElementById('mediaButton' + i);
                button.classList.remove("selected__dot__slider");
            }
        
            let stitle = document.getElementById('mediaTitle' + sid);
            stitle.classList.remove("hidden");
            let sdesc = document.getElementById('mediaDesc' + sid);
            sdesc.classList.remove("hidden");
            let simage = document.getElementById('mediaImage' + sid);
            simage.classList.remove("hidden");
            let sbutton = document.getElementById('mediaButton' + sid);
            sbutton.classList.add("selected__dot__slider");
        }
    </script>

    

    @stack('post-scripts')

</body>
</html>