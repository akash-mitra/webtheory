@extends('active.master')

@section('metadesc'){{ $data->category->metadesc . ' -' . $data->ref->site->title  }}@endsection

@section('metakeys'){{ $data->category->metakey }}@endsection

@push('headers')
<link rel="canonical" href="{{ $data->category->permalink }}">
@endpush

@section('contents')

    <div class="w-full h-1 bg-{{$data->ref->template->primaryColor}}-600 fixed top-0 shadow-lg"></div>

    <div class="w-full max-w-6xl mx-auto px-6 md:px-8">


        <main class="w-full max-w-6xl mx-auto pb-10 px-6 text-gray-800 mt-8">
            <header>
                @if(! empty($data->category->parent))
                    <a class="py-1 text-{{$data->ref->template->primaryColor}}-400" href="{{ $data->category->parent->url }}">{{ $data->category->parent->name }}</a>
                @endif
                <h1 class="text-4xl">{{ $data->category->name }}</h1>
                @if(empty($data->category->media))
                    <div class="w-full bordeqr-b">&nbsp;</div>
                @else
                    <img src="{{ $data->category->media->url }}" class="h-16 w-auto mt-2 shadown">
                @endif
                <p class="mt-2 py-4 text-xl">{{ $data->category->description }}</p>
                <div class="w-full flex">
                    <div class="bg-{{$data->ref->template->primaryColor}}-200 rounded-lg py-2 px-4 mr-3"><b>{{ count($data->category->pages) }}</b> Articles</div>
                    <div class="bg-{{$data->ref->template->primaryColor}}-200 rounded-lg py-2 px-4 mr-3"><b>{{ count($data->category->subcategories) }}</b> Sub-categories</div>
                </div>
            </header>

            <section>
                <header class="mt-8 text-2xl text-gray-600 border-b py-2">Articles</header>

                <div class="w-full md:flex md:justify-between md:flex-wrap">
                @if(count($data->category->pages)===0)
                    <p class="text-gray-600 mt-3 p-4">No article under this category</p>
                @endif
                @foreach($data->category->pages as $page)
                    <div class="w-full md:w-1/2 p-6 mb-2">

                        <h2 class="my-2 text-2xl">
                            <a href="{{ $page->url }}" class="text-gray-700 leading-tight hover:text-{{$data->ref->template->primaryColor}}-500">
                                {{ $page->title }}
                            </a>
                        </h2>
                        <p class="text-gray-700 mt-3">{{ $page->summary }}</p>
                        <p class="text-xs text-gray-700 py-2">Updated {{ $page->updated_at->format('d M, Y')}}</p>
                        <a class="mt-3 inline-block text-{{$data->ref->template->primaryColor}}-600" href="{{$page->url}}">Read More</a>
                    </div>
                @endforeach
            </section>

            <section>
                <header class="mt-8 text-2xl text-gray-600 border-b py-2">Sub-categories</header>

                <div class="w-full md:flex md:justify-between md:flex-wrap">
                @if(count($data->category->subcategories)===0)
                    <p class="text-gray-600 mt-3 p-4">No sub-category under this category</p>
                @endif
                @foreach($data->category->subcategories as $category)
                    <div class="w-full md:w-1/2 p-6 mb-2">

                        <h2 class="my-2 text-2xl">
                            <a href="{{ $category->url }}" class="text-gray-700 leading-tight hover:text-{{$data->ref->template->primaryColor}}-500">
                                {{ $category->name }}
                            </a>
                        </h2>
                        <p class="text-gray-700 mt-3">{{ $category->description }}</p>
                        <a class="mt-3 inline-block text-{{$data->ref->template->primaryColor}}-600" href="{{$category->url}}">Explore</a>
                    </div>
                @endforeach
            </section>
        </main>


    </div>

@endsection
