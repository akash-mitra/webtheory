
<div class="flex flex-col">
  <div>
    <svg
      class="fill-current w-full"
      version="1.1"
      id="Layer_1"
      xmlns="http://www.w3.org/2000/svg"
      xmlns:xlink="http://www.w3.org/1999/xlink"
      x="0px"
      y="0px"
      viewBox="0 0 1885 140"
      enable-background="new 0 0 1885 140"
      xml:space="preserve"
    >
      <linearGradient
        id="SVGID_1_"
        gradientUnits="userSpaceOnUse"
        x1="-13.4967"
        y1="75.2234"
        x2="1901.298"
        y2="75.2234"
      >
        <stop offset="0" style="stop-color:#B0ECF6" />
        <stop offset="1" style="stop-color:#87F1F6" />
      </linearGradient>
      <path
        fill="url(#SVGID_1_)"
        d="M1901.3,59.5c-251.4,35-370.5,18.9-517.8-27.3C1236.2-14,1148.1,12.9,977.3,73.1
c-170.9,60.2-406-41.8-582.8-41.8c-176.7,0-283,61.2-408,61.2v49.2h1914.1L1901.3,59.5z"
      />
      <linearGradient
        id="SVGID_2_"
        gradientUnits="userSpaceOnUse"
        x1="-10.7948"
        y1="84.23"
        x2="1904"
        y2="84.23"
      >
        <stop offset="0" style="stop-color:#CDF2FF" />
        <stop offset="1" style="stop-color:#88FCFF" />
      </linearGradient>
      <path
        fill="url(#SVGID_2_)"
        d="M1904,68.5c-251.4,35-370.5,18.9-517.8-27.3C1238.9-5,1150.8,21.9,980,82.1
c-170.9,60.2-406-41.8-582.8-41.8c-176.7,0-283,61.2-408,61.2v49.2h1914.1L1904,68.5z"
      />
      <path
        fill="#E7FBFF"
        d="M1896.8,86.5c-251.4,35-370.5,18.9-517.8-27.3c-147.3-46.2-235.4-19.3-406.2,40.9
c-170.9,60.2-406-41.8-582.8-41.8c-176.7,0-283,61.2-408,61.2v49.2h1914.1L1896.8,86.5z"
      />
    </svg>
  </div>
  <div class="flex flex-col" style="background: #e7fbff;">
    <div class="container flex w-full self-center px-16">
      <div class="flex flex-col lg:flex-row w-full">
        <div class="lg:w-3/5 w-full">
          <div
            id="contact"
            class="text-xl pt-10 lg:text-4xl leading-tight tracking-normal font-bold self-center"
            style="color:#0061af;"
          >
            Get In Touch
          </div>
          <form method="POST" action="#" class="w-full">
            @csrf
            <div class="flex flex-col md:flex-row justify-between">
              <div class="flex flex-col  w-full">
                <label
                  for="name"
                  class="block uppercase tracking-wide text-gray-700 text-sm mb-2"
                  >Name</label
                >
                <input
                  class="appearance-none block w-full bg-white text-gray-700 border border-gray-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none"
                  type="name"
                  name="name"
                  id="name"
                  placeholder="Full Name"
                  value="{{ old('name') }}"
                />
                @error('name')
                <span
                  class="text-red-600 name"
                  >{{ $errors->first('name') }}</span
                >
                @enderror
              </div>
              <div class="flex flex-col w-full lg:ml-8">
                <label
                  for="name"
                  class="block uppercase tracking-wide text-gray-700 text-sm mb-2"
                  >Company</label
                >
                <input
                  class="appearance-none block w-full bg-white text-gray-700 border border-gray-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none"
                  type="text"
                  name="company"
                  id="company"
                  placeholder="Company Name"
                  value="{{ old('company_name') }}"
                />
                @error('company_name')
                <span
                  class="text-red-600 company_name"
                  >{{ $errors->first('company_name') }}</span
                >
                @enderror
              </div>
            </div>
            <div class="flex flex-col md:flex-row justify-between">
              <div class="flex flex-col w-full">
                <label
                  for="name"
                  class="block uppercase tracking-wide text-gray-700 text-sm mb-2"
                  >Business Email</label
                >
                <input
                  class="appearance-none block w-full bg-white text-gray-700 border border-gray-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none"
                  type="text"
                  name="email"
                  id="email"
                  placeholder="Email"
                  value="{{ old('email') }}"
                />
                @error('email')
                <span
                  class="text-red-600 email"
                  >{{ $errors->first('email') }}</span
                >
                @enderror
              </div>
            </div>

            <div class="flex flex-col md:flex-row justify-between">
              <div class="flex flex-col w-full">
                <label
                  for="phone"
                  class="block uppercase tracking-wide text-gray-700 text-sm mb-2"
                  >Phone</label
                >
                <input
                  class="appearance-none block w-full bg-white text-gray-700 border border-gray-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none"
                  type="text"
                  name="phone"
                  id="phone"
                  placeholder="Phone number with country code"
                  value="{{ old('phone') }}"
                />
                @error('phone')
                <span
                  class="text-red-600 phone"
                  >{{ $errors->first('phone') }}</span
                >
                @enderror
              </div>
              <div class="flex flex-col  w-full lg:ml-8">
                <label
                  for="job_title"
                  class="block uppercase tracking-wide text-gray-700 text-sm mb-2"
                  >Job Title</label
                >
                <input
                  class="appearance-none block w-full bg-white text-gray-700 border border-gray-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none"
                  type="text"
                  name="job_title"
                  id="job_title"
                  placeholder="Enter job title"
                  value="{{ old('job_title') }}"
                />
                @error('job_title')
                <span
                  class="text-red-600 job_title"
                  >{{ $errors->first('job_title') }}</span
                >
                @enderror
              </div>
            </div>

            <div class="flex flex-col md:flex-row justify-between">
              <div class="flex flex-col lg:w-1/2 w-full">
                <label
                  for="country"
                  class="block uppercase tracking-wide text-gray-700 text-sm mb-2"
                  >Country</label
                >
                <div class="relative">
                  <select
                    name="country"
                    id="country"
                    class="block appearance-none bg-white border border-gray-500 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:border-gray-500 w-full"
                  >
                    <option value="">Select a Country</option>
                    {{-- <option
                      v-for="(country, index) in countries"
                      :key="index"
                      :value="country.country"
                      >{{ country.country }}</option
                    > --}}
                    <option value="India">India</option>
                    <option value="Singapore">Singapore</option>
                    <option value="United States">United States</option>
                  </select>
                  <div
                    class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-700"
                  >
                    <svg
                      class="fill-current h-4 w-4"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                    >
                      <path
                        d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                      />
                    </svg>
                  </div>
                </div>
                @error('country')
                <span
                  class="text-red-600 country"
                  >{{ $errors->first('country') }}</span
                >
                @enderror
              </div>
              <div class="flex flex-col lg:w-1/2 w-full lg:ml-8">
                <label
                  for="interested"
                  class="block uppercase tracking-wide text-gray-700 text-sm mb-2"
                  >I'm interested to</label
                >
                <div class="relative">
                  <select
                    name="interested"
                    id="interested"
                    class="block appearance-none bg-white border border-gray-500 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:border-gray-500 w-full"
                    value="{{ old('interested') }}"
                  >
                    <option value="">Select a option</option>
                    <option value="Talk to representative"
                      >Talk to representative</option
                    >
                    <option value="Buy Subscription">Buy Subscription</option>
                    <option value="Others">Others</option>
                  </select>
                  <div
                    class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700"
                  >
                    <svg
                      class="fill-current h-4 w-4"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                    >
                      <path
                        d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                      />
                    </svg>
                  </div>
                </div>
                @error('interested')
                <span
                  class="text-red-600 interested"
                  >{{ $errors->first('interested') }}</span
                >
                @enderror
              </div>
            </div>
            {{-- <div class="flex flex-col justify-center mt-4">
              <div class="self-center">
                <vue-recaptcha
                  ref="recaptcha"
                  @verify="onCaptchaVerified"
                  @expired="onCaptchaExpired"
                  :sitekey="recaptchaSiteKey"
                ></vue-recaptcha>
                @error('recaptchaToken')
                <span
                  class="text-red-600 recaptchaToken"
                  >{{ $errors->first('recaptchaToken') }}</span
                >
                @enderror
              </div>
            </div> --}}
            <div class="flex flex-col md:flex-row py-4 justify-center">
              <div class="w-full">
                <button
                  type="submit"
                  class="btn py-2 px-4 rounded inline-flex justify-center w-full"
                  style="background-color: #bae314; border-color: #bae314"
                >
                  <span class="uppercase font-bold">Send</span>

                  <svg
                    class="fill-current h-4 w-4 ml-2 self-center"
                    version="1.1"
                    id="Capa_1"
                    xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink"
                    x="0px"
                    y="0px"
                    viewBox="0 0 495.003 495.003"
                    style="enable-background:new 0 0 495.003 495.003;"
                    xml:space="preserve"
                  >
                    <g id="XMLID_51_">
                      <path
                        id="XMLID_53_"
                        d="M164.711,456.687c0,2.966,1.647,5.686,4.266,7.072c2.617,1.385,5.799,1.207,8.245-0.468l55.09-37.616
  l-67.6-32.22V456.687z"
                      />
                      <path
                        id="XMLID_52_"
                        d="M492.431,32.443c-1.513-1.395-3.466-2.125-5.44-2.125c-1.19,0-2.377,0.264-3.5,0.816L7.905,264.422
  c-4.861,2.389-7.937,7.353-7.904,12.783c0.033,5.423,3.161,10.353,8.057,12.689l125.342,59.724l250.62-205.99L164.455,364.414
  l156.145,74.4c1.918,0.919,4.012,1.376,6.084,1.376c1.768,0,3.519-0.322,5.186-0.977c3.637-1.438,6.527-4.318,7.97-7.956
  L494.436,41.257C495.66,38.188,494.862,34.679,492.431,32.443z"
                      />
                    </g>
                  </svg>
                </button>
              </div>
            </div>
          </form>
        </div>
        <div class="lg:ml-8 lg:w-2/5 w-full flex-grow-0">
          <div
            class="text-xl pt-10 lg:text-4xl leading-tight tracking-normal font-bold self-center"
            style="color:#0061af;"
          >
            Octosum Blogs
          </div>
          <div class="flex flex-col mt-6">
            @if(count($data->pages) > 0)
            <div>
              <div class="font-semibold">{{ $data->pages[0]->title }}</div>
              <div class="mt-4">{{ $data->pages[0]->summary }}</div>
              <div
                class="mt-4 border-b pb-2"
                style="text-color: #195eaa; border-color: #195eaa"
              >
                <a
                  href="{{ $data->pages[0]->url }}"
                  class="cursor-pointer"
                  style="color: #195eaa; border-color: #195eaa"
                  >Read More</a
                >
              </div>
            </div>
            @endif
          </div>
        </div>
      </div>
    </div>
    <div
      class="container w-full my-16 self-center px-16 flex flex-col md:flex-row justify-between"
    >
      <div class="flex">
        <div>
          <svg
            class="fill-current h-10 w-10 lg:h-16 lg:w-16"
            version="1.1"
            id="Capa_1"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            x="0px"
            y="0px"
            viewBox="0 0 522.8 521.7"
            enable-background="new 0 0 522.8 521.7"
            xml:space="preserve"
          >
            <circle
              fill="#FFFFFF"
              stroke="#46BBD9"
              stroke-width="13"
              stroke-miterlimit="10"
              cx="264.6"
              cy="259.8"
              r="253"
            />
            <g>
              <g>
                <path
                  fill="#46BBD9"
                  d="M384.7,150.6H146.1c-14,0-25.4,11.4-25.4,25.4v169.6c0,14,11.4,25.4,25.4,25.4h238.6
    c14,0,25.4-11.4,25.4-25.4V176.1C410.1,162.1,398.7,150.6,384.7,150.6z M381.2,167.6L265.9,282.8L149.7,167.6L381.2,167.6
    L381.2,167.6z M137.6,342.2V179.5l81.7,81L137.6,342.2z M149.6,354.1l81.7-81.7l28.6,28.4c3.3,3.3,8.7,3.3,12,0l27.9-27.9
    l81.3,81.3H149.6V354.1z M393.2,342.2l-81.3-81.3l81.3-81.3V342.2z"
                />
              </g>
            </g>
          </svg>
        </div>
        <div class="self-center ml-4 text-sm lg:text-lg  font-medium ">
          contact@octosum.com <br />
          info@octosum.com
        </div>
      </div>
      <div class="flex mt-4 lg:mt-0">
        <div>
          <svg
            class="fill-current h-10 w-10 lg:h-16 lg:w-16"
            version="1.1"
            id="Capa_1"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            x="0px"
            y="0px"
            viewBox="0 0 522.8 521.7"
            enable-background="new 0 0 522.8 521.7"
            xml:space="preserve"
          >
            <g>
              <circle
                fill="#FFFFFF"
                stroke="#46BBD9"
                stroke-width="13"
                stroke-miterlimit="10"
                cx="261.4"
                cy="260.9"
                r="253"
              />
              <g>
                <g>
                  <path
                    fill="#46BBD9"
                    d="M377.3,304.8c-16.8,0-33.3-2.6-48.9-7.8c-7.8-2.7-16.6-0.6-21.7,4.6l-30.8,23.3
      c-35.7-19.1-57.8-41.1-76.6-76.6l22.6-30c5.9-5.9,8-14.4,5.4-22.4c-5.2-15.7-7.8-32.2-7.8-49c0-12.1-9.9-22-22-22h-50.3
      c-12.1,0-22,9.9-22,22c0,139,113.1,252.1,252.1,252.1c12.1,0,22-9.9,22-22v-50.2C399.2,314.7,389.4,304.8,377.3,304.8z M384,377
      c0,3.7-3,6.8-6.8,6.8c-130.6,0-236.9-106.3-236.9-236.9c0-3.7,3-6.8,6.8-6.8h50.3c3.7,0,6.8,3,6.8,6.8c0,18.4,2.9,36.5,8.6,53.6
      c0.8,2.5,0.1,5.1-2.4,7.8L184.2,243c-1.8,2.3-2,5.4-0.7,8c21.4,42,47.3,67.9,89.6,89.6c2.6,1.3,5.7,1.1,8.1-0.7l35.5-26.9
      c1.8-1.8,4.5-2.4,6.9-1.6c17.2,5.7,35.3,8.6,53.7,8.6c3.7,0,6.8,3,6.8,6.8L384,377L384,377z"
                  />
                </g>
              </g>
            </g>
          </svg>
        </div>
        <div class="self-center ml-4 text-sm lg:text-lg  font-medium ">
          +65 64383504
        </div>
      </div>
      <div class="flex mt-4 lg:mt-0">
        <div>
          <svg
            class="fill-current h-10 w-10 lg:h-16 lg:w-16"
            version="1.1"
            id="Capa_1"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            x="0px"
            y="0px"
            viewBox="0 0 522.8 521.7"
            enable-background="new 0 0 522.8 521.7"
            xml:space="preserve"
          >
            <g>
              <circle
                fill="#FFFFFF"
                stroke="#46BBD9"
                stroke-width="13"
                stroke-miterlimit="10"
                cx="261.4"
                cy="260.9"
                r="253"
              />
              <g>
                <g>
                  <g>
                    <path
                      fill="#46BBD9"
                      d="M352.5,173.3c-20.8-30-53.7-47.3-90.3-47.3c-36.6,0-69.5,17.2-90.3,47.3
        c-20.7,29.9-25.4,67.7-12.8,101.2c3.4,9.1,8.8,18,15.9,26.3l79.9,93.8c1.8,2.1,4.5,3.3,7.2,3.3c2.8,0,5.4-1.2,7.2-3.3l79.9-93.8
        c7.2-8.4,12.6-17.2,15.9-26.3C377.9,241,373.1,203.2,352.5,173.3z M347.4,267.9c-2.6,7-6.8,13.9-12.5,20.5c0,0,0,0,0,0.1
        l-72.6,85.3l-72.7-85.4c-5.7-6.6-10-13.6-12.6-20.6c-10.5-27.7-6.5-58.9,10.6-83.7c17.2-24.8,44.4-39.1,74.6-39.1
        c30.3,0,57.5,14.2,74.6,39.1C353.9,208.8,357.9,240.1,347.4,267.9z"
                    />
                  </g>
                </g>
                <g>
                  <g>
                    <path
                      fill="#46BBD9"
                      d="M262.2,182.4c-29.4,0-53.3,23.9-53.3,53.3s23.9,53.3,53.3,53.3c29.4,0,53.3-23.9,53.3-53.3
        C315.5,206.3,291.6,182.4,262.2,182.4z M262.2,269.9c-18.9,0-34.2-15.4-34.2-34.2s15.4-34.2,34.2-34.2
        c18.8,0,34.2,15.4,34.2,34.2S281.1,269.9,262.2,269.9z"
                    />
                  </g>
                </g>
              </g>
            </g>
          </svg>
        </div>
        <div
          class="self-center ml-4 text-sm lg:text-lg  font-medium  text-left"
        >
          36 Robinson Road, #14-04 City House, Singapore – 068877
        </div>
      </div>
    </div>
  </div>
</div>
