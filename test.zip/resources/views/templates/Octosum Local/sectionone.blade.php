
<div>
  <div class="pt-6 lg:pt-0" style="background: #e7fbff;">
    <div
      class="container px-8 md:px-16 mx-auto flex flex-wrap flex-col md:flex-row justify-between"
    >
      <!--Left Col-->
      <div
        class="flex flex-col w-full md:w-1/2 justify-center text-center md:text-left"
      >
        <div>
          <p class="text-3xl md:text-5xl tracking-tighter font-thin">
            The intelligent subscription management system for your enterprise
          </p>
          <p
            class="text-xl md:text-3xl tracking-tighter font-thin text-gray-600"
          >
            Manage all your open source subscriptions on a single platform
          </p>
        </div>
      </div>
      <!--Right Col-->
      <div class="w-full md:w-1/2 py-6 text-center self-end">
        <img class="w-full z-50" src="/media/home.png" />
      </div>
    </div>
  </div>
  <div>
    <svg
      class="fill-current"
      version="1.1"
      id="Layer_1"
      xmlns="http://www.w3.org/2000/svg"
      xmlns:xlink="http://www.w3.org/1999/xlink"
      x="0px"
      y="0px"
      viewBox="0 0 1885 261"
      enable-background="new 0 0 1885 261"
      xml:space="preserve"
    >
      <g>
        <linearGradient
          id="SVGID_1_"
          gradientUnits="userSpaceOnUse"
          x1="-4.3247"
          y1="1902.1935"
          x2="1891"
          y2="1902.1935"
          gradientTransform="matrix(1 0 0 -1 0 2043.3868)"
        >
          <stop offset="0" style="stop-color:#B0ECF6" />
          <stop offset="1" style="stop-color:#87F1F6" />
        </linearGradient>
        <path
          fill="url(#SVGID_1_)"
          d="M1891,166.7V25.4H-4.3v134.5c35.8,15.9,72,25.3,101.1,25.3c133,17.1,265.9-21.1,394.1-56
  c128.4-34.9,265.3-67.1,395.3-38.4c126.1,27.9,228.1,109.4,351.5,144.8c179.7,51.6,374.4-0.4,556.2-46.2
  C1825.7,181.4,1858.2,173.6,1891,166.7z"
        />

        <linearGradient
          id="SVGID_2_"
          gradientUnits="userSpaceOnUse"
          x1="-4.3247"
          y1="1912.1935"
          x2="1891"
          y2="1912.1935"
          gradientTransform="matrix(1 0 0 -1 0 2043.3868)"
        >
          <stop offset="0" style="stop-color:#CDF2FF" />
          <stop offset="1" style="stop-color:#88FCFF" />
        </linearGradient>
        <path
          fill="url(#SVGID_2_)"
          d="M1891,156.7V15.4H-4.3v134.5c35.8,15.9,72,25.3,101.1,25.3c133,17.1,265.9-21.1,394.1-56
  c128.4-34.9,265.3-67.1,395.3-38.4c126.1,27.9,228.1,109.4,351.5,144.8c179.7,51.6,374.4-0.4,556.2-46.2
  C1825.7,171.4,1858.2,163.6,1891,156.7z"
        />
        <path
          fill="#E7FBFF"
          d="M1891,134.7V-6.6H-4.3v134.5c35.8,15.9,72,25.3,101.1,25.3c133,17.1,265.9-21.1,394.1-56
  c128.4-34.9,265.3-67.1,395.3-38.4c126.1,27.9,228.1,109.4,351.5,144.8c179.7,51.6,374.4-0.4,556.2-46.2
  C1825.7,149.4,1858.2,141.6,1891,134.7z"
        />
      </g>
    </svg>
  </div>
</div>
