@extends('active.master')

@section('title'){{ $data->ref->site->title  }}@endsection

@section('metadesc'){{ $data->ref->site->desc  }}@endsection

@section('metakeys'){{ 'subscription management, open source subscription management, subscription management as a service, easy subscription management, open source marketplace, easy procurement management' }}@endsection

@push('headers')
<link rel="canonical" href="{{ url('blog')}}">
@endpush


@push('styles')
<style>

.vue-tablist {
  list-style: none;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  padding-left: 0;
}
.vue-tab {
  padding: 5px 10px;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  position: relative;
  bottom: -1px;
  text-transform: uppercase;
  color: #0061af;
  font-weight: 700;
}
.vue-tab[aria-selected="true"] {
  border-bottom-width: 4px;
  border-color: #bae314;
}
.vue-tab[aria-disabled="true"] {
  cursor: not-allowed;
  color: #999;
}


.videoWrapper {
  position: relative;
  padding-bottom: calc(var(--aspect-ratio, 0.5625) * 100%);
  height: 0;
}
.videoWrapper iframe {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}


.selected__dot__slider {
  background-color: #bae314!important;
  border-color: #bae314!important;
}
.dot__slider {
  border-radius: 9999px;
  height: 1.5rem;
  width: 1.5rem;
  display: flex;
  -webkit-box-align: center;
  align-items: center;
  -webkit-box-pack: center;
  @apply justify-center;
  border-width: 1px;
  font-weight: 700;
  margin-right: .5rem;
  background-color: #e2e8f0;
  border-color: #e2e8f0;
}
</style>
@endpush

@section('contents')

  @include('active.sectionone')
  
  @include('active.sectiontwo')
  
  @include('active.sectionthree')
  
  @include('active.sectionfour')

  @include('active.sectionfive')

@endsection

@push('post-scripts')

@endpush